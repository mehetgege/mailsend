    <footer class="bg-light text-center py-3 mt-5">
        <p>© 2025 Mail Gönderim Sistemi. Tüm hakları saklıdır.</p>
    </footer>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <!-- Chart.js (Raporlar için) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- CodeMirror JS (MJML Editör için) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/xml/xml.min.js"></script>
    <!-- MJML JS (MJML kodunu HTML’e dönüştürmek için) -->
    <script src="assets/js/mjml-browser.js"></script>
    <!-- Özel JS -->
    <script>
        // Loading animasyonu
        $(document).ready(function() {
            $('form').on('submit', function() {
                $('#loadingOverlay').show();
            });

            // DataTables Başlatma (Müşteri Listesi, Şablon Listesi, Gönderim Kayıtları gibi sayfalarda kullanılır)
            $('table.table-bordered').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.13.6/i18n/tr.json"
                },
                "pageLength": 10,
                "lengthMenu": [10, 25, 50, 100],
                "order": [[0, "desc"]]
            });
        });
    </script>
    <!-- MJML Test Kodu -->
    <script>
        window.onload = function() {
            if (typeof mjml2html === 'undefined') {
                console.error('mjml2html fonksiyonu tanımlı değil! MJML kütüphanesi yüklenmemiş olabilir.');
            } else {
                console.log('MJML kütüphanesi başarıyla yüklendi. mjml2html fonksiyonu mevcut.');
            }
        };
    </script>
</body>
</html>