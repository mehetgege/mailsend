// algorithms/indicators.js

export function calculateRSI(prices, period) {
    if (prices.length < period) {
        return [];
    }
    
    let gains = 0;
    let losses = 0;
    const rsi = [];
    
    for (let i = 1; i <= period; i++) {
        const diff = prices[i] - prices[i - 1];
        if (diff > 0) {
            gains += diff;
        } else {
            losses -= diff;
        }
    }
    
    let prevAvgGain = gains / period;
    let prevAvgLoss = losses / period;
    
    const initialRs = prevAvgLoss === 0 ? Infinity : prevAvgGain / prevAvgLoss;
    rsi.push(100 - (100 / (1 + initialRs)));
    
    for (let i = period + 1; i < prices.length; i++) {
        const diff = prices[i] - prices[i - 1];
        const gain = diff > 0 ? diff : 0;
        const loss = diff < 0 ? -diff : 0;
        
        prevAvgGain = (prevAvgGain * (period - 1) + gain) / period;
        prevAvgLoss = (prevAvgLoss * (period - 1) + loss) / period;
        
        const rs = prevAvgLoss === 0 ? Infinity : prevAvgGain / prevAvgLoss;
        const rsiValue = 100 - (100 / (1 + rs));
        rsi.push(rsiValue);
    }
    
    return rsi;
}

export function calculateATR(candles, period) {
    if (!candles || candles.length < period + 1) {
        return null;
    }
    
    const trs = [];
    for (let i = 1; i < candles.length; i++) {
        const c = candles[i];
        const p = candles[i - 1];
        trs.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
    }
    
    if (trs.length < period) {
        return null;
    }
    
    let atr = trs.slice(0, period).reduce((a, b) => a + b, 0) / period;

    for (let i = period; i < trs.length; i++) {
        atr = (atr * (period - 1) + trs[i]) / period;
    }
    
    return atr;
}

export function calculateVWAP(candles) {
    if (!candles || candles.length === 0) {
        return null;
    }
    
    let cumPV = 0;
    let cumV = 0;
    
    for (const k of candles) {
        const tp = (k.high + k.low + k.close) / 3;
        cumPV += tp * k.volume;
        cumV += k.volume;
    }
    
    return cumV ? (cumPV / cumV) : null;
}

export function calculateBB(candles, period, stdDev) {
    if (!candles || candles.length < period) {
        return null;
    }
    
    const closes = candles.map(c => c.close);
    const slice = closes.slice(-period);
    
    const sma = slice.reduce((a, b) => a + b, 0) / period;
    const std = Math.sqrt(
        slice.map(p => Math.pow(p - sma, 2)).reduce((a, b) => a + b, 0) / period
    );
    
    const upper = sma + (std * stdDev);
    const lower = sma - (std * stdDev);
    const middle = sma;

    return { upper, middle, lower };
}

export function calculateSuperTrend(candles, period, mult) {
    if (!candles || candles.length < period + 1) {
        return [];
    }

    const trs = [];
    for (let i = 1; i < candles.length; i++) {
        const c = candles[i];
        const p = candles[i - 1];
        trs.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
    }

    let atr = trs.slice(0, period).reduce((a, b) => a + b, 0) / period;
    const superTrends = [];
    let isUpTrend = true;
    let upBand = 0;
    let downBand = 0;

    for (let i = period; i < candles.length; i++) {
        atr = (atr * (period - 1) + trs[i - 1]) / period;
        const middle = (candles[i].high + candles[i].low) / 2;
        
        let newUpBand = middle + (mult * atr);
        let newDownBand = middle - (mult * atr);

        if (i > period) {
            newUpBand = (newUpBand < upBand || candles[i - 1].close > upBand) ? newUpBand : upBand;
            newDownBand = (newDownBand > downBand || candles[i - 1].close < downBand) ? newDownBand : downBand;
        }

        upBand = newUpBand;
        downBand = newDownBand;

        const previousSuperTrend = i > period ? superTrends[i - period - 1] : 0;

        if (isUpTrend) {
            if (candles[i].close < downBand) {
                isUpTrend = false;
                superTrends.push(upBand);
            } else {
                superTrends.push(downBand);
            }
        } else {
            if (candles[i].close > upBand) {
                isUpTrend = true;
                superTrends.push(downBand);
            } else {
                superTrends.push(upBand);
            }
        }
    }
    return superTrends;
}
