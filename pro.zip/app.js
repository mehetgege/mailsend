// app.js

import { EventBus } from './services/event-bus.js';
import { StateManager } from './services/state-manager.js';
import { DataService } from './services/data-service.js';
import { LoggerService } from './services/logger-service.js';
import { UIService } from './services/ui-service.js';
import { WebSocketService } from './services/websocket-service.js';

import { StrategyHub } from './modules/strategy-hub.js';
import { AdvancedConfluenceEngine } from './modules/confluence-engine.js';
import { OracleSystem } from './modules/oracle-system.js';
import { PantheonCouncil } from './modules/pantheon-council.js';
import { RitualEngine } from './modules/ritual-engine.js';
import { EnergyReactor } from './modules/energy-reactor.js';
import { VisualizerCore } from './modules/visualizer-core.js';
import { RiskAssessmentManager } from './modules/risk-manager.js';
import { GuardianProtocol } from './modules/guardian-protocol.js';

class TradingWarRoom {
    constructor() {
        this.eventBus = new EventBus();
        this.stateManager = new StateManager(this.eventBus);
        this.dataService = new DataService(this.eventBus, this.stateManager);
        this.logger = new LoggerService(this.eventBus);
        this.ui = new UIService(this.eventBus, this.stateManager);
        this.websocketService = new WebSocketService(this.eventBus, this.stateManager);

        this.modules = {
            strategies: new StrategyHub(this.eventBus, this.stateManager),
            confluence: new AdvancedConfluenceEngine(this.eventBus, this.stateManager),
            oracle: new OracleSystem(this.eventBus, this.stateManager),
            pantheon: new PantheonCouncil(this.eventBus, this.stateManager),
            rituals: new RitualEngine(this.eventBus, this.stateManager),
            energy: new EnergyReactor(this.eventBus, this.stateManager),
            visualizer: new VisualizerCore(this.eventBus, this.stateManager),
            risk: new RiskAssessmentManager(this.eventBus, this.stateManager),
            guardian: new GuardianProtocol(this.eventBus, this.stateManager)
        };
    }

    async init() {
        this.logger.log('Trading War Room başlatılıyor...');
        await this.dataService.loadInitialData();
        
        this.ui.init();
        Object.values(this.modules).forEach(module => module.init());
        
        this.eventBus.publish('app:ready');
        this.logger.log('Sistem kullanıma hazır.');

        this.eventBus.subscribe('ui:start_clicked', () => this.startSystem());
        this.eventBus.subscribe('ui:stop_clicked', () => this.stopSystem());
        this.eventBus.subscribe('system:stop_requested', () => this.stopSystem());
    }

    async startSystem() {
        if (this.stateManager.getState('isRunning')) return;
        this.stateManager.setState('isRunning', true);
        this.logger.log('Sistem başlatıldı. Canlı veri akışı başlıyor.');
        this.eventBus.publish('system:start');
        
        const symbol = this.stateManager.getState('currentSymbol');
        const timeframe = this.stateManager.getState('currentTimeframe');
        this.websocketService.connect(symbol, timeframe);
    }

    stopSystem() {
        if (!this.stateManager.getState('isRunning')) return;
        this.stateManager.setState('isRunning', false);
        this.logger.log('Sistem durduruldu.');
        this.eventBus.publish('system:stop');
        
        this.websocketService.disconnect();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new TradingWarRoom();
    window.app.init();
});

export { TradingWarRoom };
