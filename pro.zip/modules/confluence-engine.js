// modules/confluence-engine.js

class AdvancedConfluenceEngine {
    constructor(eventBus, stateManager) { 
        this.eventBus = eventBus; 
        this.stateManager = stateManager; 
        this.proposals = []; 
        this.lastSignalTime = 0; 
        this.lastSignalTimeByDirection = { buy: 0, sell: 0 };
        this.lastDirection = null;
        this.buyScore = 0;
        this.sellScore = 0;

        this.eventBus.subscribe('strategy:signal_proposal', (proposal) => this.propose(proposal.strategy, proposal.direction, proposal.reason, proposal.score));
        this.eventBus.subscribe('system:start', () => this.startAnalysisLoop());
        this.eventBus.subscribe('system:stop', () => this.stopAnalysisLoop());
        this.eventBus.publish('log', 'Confluence Engine başlatıldı.');
    }
    
    init() {
        this.stateManager.setNestedState('modules.confluence.buyScore', this.buyScore);
        this.stateManager.setNestedState('modules.confluence.sellScore', this.sellScore);
    }

    propose(strategy, direction, reason, score) {
        const now = Date.now();
        this.proposals = this.proposals.filter(p => !(p.strategy === strategy));
        this.proposals.push({ strategy, direction, reason, score, timestamp: now });
        this.checkConfluence();
    }
    
    startAnalysisLoop() {
        this.analysisInterval = setInterval(() => this.checkConfluence(), 500);
    }

    stopAnalysisLoop() {
        if (this.analysisInterval) {
            clearInterval(this.analysisInterval);
        }
    }

    checkConfluence() {
        const now = Date.now();
        const settings = this.stateManager.getState('settings');
        const cd = settings.cooldowns || {};
        const proposalTimeout = cd.proposalTimeoutMs ?? 3000;
        const signalCooldown = cd.signalMs ?? 15000;
        const sameDirCooldown = cd.sameDirectionMs ?? 30000;
        const oppCooldown = cd.oppositeDirectionMs ?? 20000;
        const reverseHys = cd.reverseHysteresisPoints ?? 2;
        const dirMargin = settings.optimization.dirMargin ?? 0.5;
        const minThreshold = settings.confluenceThreshold || 3;
        
        if (now - this.lastSignalTime < signalCooldown) return;
        this.proposals = this.proposals.filter(p => now - p.timestamp < proposalTimeout);

        const buy = this._computeDirectional('buy');
        const sell = this._computeDirectional('sell');

        let buyScoreAdj = buy.score;
        let sellScoreAdj = sell.score;
        
        const q = settings.optimization.signalQuality || { minContributors: 1, minGroups: 1 };
        const buyOk = (buy.contributorsCount >= q.minContributors) && (buy.groupsCount >= q.minGroups);
        const sellOk = (sell.contributorsCount >= q.minContributors) && (sell.groupsCount >= q.minGroups);

        buyScoreAdj = buyOk ? buyScoreAdj : -Infinity;
        sellScoreAdj = sellOk ? sellScoreAdj : -Infinity;
        
        this.buyScore = buyScoreAdj;
        this.sellScore = sellScoreAdj;
        this.stateManager.setNestedState('modules.confluence', { buyScore: this.buyScore, sellScore: this.sellScore });

        if (buyScoreAdj >= minThreshold && (buyScoreAdj > sellScoreAdj + dirMargin)) {
            if (now - this.lastSignalTimeByDirection.buy < sameDirCooldown) return;
            if (this.lastDirection === 'sell' && (now - this.lastSignalTime) < oppCooldown) {
                if (buyScoreAdj < (minThreshold + reverseHys)) return;
            }
            this.generateFinalSignal('buy', buy.contributors, buyScoreAdj);
        } else if (sellScoreAdj >= minThreshold && (sellScoreAdj > buyScoreAdj + dirMargin)) {
            if (now - this.lastSignalTimeByDirection.sell < sameDirCooldown) return;
            if (this.lastDirection === 'buy' && (now - this.lastSignalTime) < oppCooldown) {
                if (sellScoreAdj < (minThreshold + reverseHys)) return;
            }
            this.generateFinalSignal('sell', sell.contributors, sellScoreAdj);
        }
    }
    
    _computeDirectional(direction) {
        const now = Date.now();
        const decaySec = 3;
        const groupSums = { trending: 0, meanReversion: 0, neutral: 0 };
        const used = [];
        const groupsUsed = new Set();
        
        const activeProposals = this.proposals.filter(p => p.direction === direction);
        
        for (const p of activeProposals) {
            // Note: strategyStats is not populated by other modules in this project.
            // We default to a weight of 1 to prevent errors.
            const strategyStats = this.stateManager.getNestedState(`strategyStats.${p.strategy}`);
            const w = (strategyStats && strategyStats.overall && strategyStats.overall.weight) ? strategyStats.overall.weight : 1;
            const ageSec = (now - p.timestamp) / 1000;
            const decay = Math.exp(-ageSec / decaySec);
            const eff = p.score * w * decay;
            const grp = this.stateManager.getNestedState(`strategyStats.${p.strategy}.group`);
            
            groupsUsed.add(grp);
            groupSums[grp] = (groupSums[grp] || 0) + eff;
            used.push({ strategy: p.strategy, baseScore: p.score, weight: w, decay, effScore: eff });
        }
        
        const score = Object.values(groupSums).reduce((sum, val) => sum + val, 0); 
        return { score, contributors: used, groupSums, groupsCount: groupsUsed.size, contributorsCount: used.length };
    }

    generateFinalSignal(direction, contributors, finalScore) {
        const contributingStrats = contributors.map(c => c.strategy).join(', ');
        const status = this.stateManager.getNestedState('settings.features.enableCandleConfirm') ? 'pending' : 'active';
        
        const signal = { 
            id: `sig_${Date.now()}`, timestamp: Date.now(), symbol: this.stateManager.getState('currentSymbol'), 
            direction, price: this.stateManager.getNestedState('marketData.price'), score: finalScore, 
            reason: contributingStrats, contributors, status: status, note: ''
        };
        
        this.eventBus.publish('signal:final', signal);

        this.proposals = [];
        const now = Date.now();
        this.lastSignalTime = now;
        this.lastSignalTimeByDirection[direction] = now;
        this.lastDirection = direction;
    }
}

export { AdvancedConfluenceEngine };
