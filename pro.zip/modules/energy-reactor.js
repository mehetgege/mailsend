// modules/energy-reactor.js

class EnergyReactor {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.currentEnergy = 80;
        this.maxEnergy = 100;
        this.minEnergy = 10;
        this.decayRate = 0.05;
        this.lastUpdateTime = Date.now();
        this.criticalThreshold = 20;
        
        this.systemHeat = 0;
        this.coolingRate = 0.1;

        this.eventBus.subscribe('system:start', () => this.startDecay());
        this.eventBus.subscribe('system:stop', () => this.stopDecay());
        this.eventBus.subscribe('energy:use', (amount) => this.useEnergy(amount));
        this.eventBus.subscribe('energy:add', (amount) => this.addEnergy(amount));
        this.eventBus.subscribe('ui:boost_energy', () => this.boostEnergy());
        this.eventBus.subscribe('ui:optimize_energy', () => this.optimizeEnergy());
        this.eventBus.subscribe('ui:recycle_energy', () => this.recycleEnergy());
        this.eventBus.subscribe('system:combat_mode_active', (isActive) => {
            if (isActive) {
                this.decayRate = 0.1;
            } else {
                this.decayRate = 0.05;
            }
        });
    }

    init() {
        this.loadState();
        this.stateManager.setNestedState('modules.energy.currentEnergy', this.currentEnergy);
        this.stateManager.setNestedState('modules.energy.systemHeat', this.systemHeat);
        this.eventBus.publish('log', 'Energy Reactor başlatıldı.');
    }

    loadState() {
        const savedEnergy = localStorage.getItem('utc_energy_level');
        if (savedEnergy) {
            this.currentEnergy = parseFloat(savedEnergy);
        }
        const savedHeat = localStorage.getItem('utc_system_heat');
        if (savedHeat) {
            this.systemHeat = parseFloat(savedHeat);
        }
    }

    startDecay() {
        this.decayInterval = setInterval(() => {
            const now = Date.now();
            const deltaTime = (now - this.lastUpdateTime) / 1000;
            this.lastUpdateTime = now;

            this.currentEnergy = Math.max(this.minEnergy, this.currentEnergy - (this.decayRate * deltaTime));
            this.systemHeat = Math.max(0, this.systemHeat - (this.coolingRate * deltaTime));

            this.stateManager.setNestedState('modules.energy.currentEnergy', this.currentEnergy);
            this.stateManager.setNestedState('modules.energy.systemHeat', this.systemHeat);
            
            localStorage.setItem('utc_energy_level', this.currentEnergy);
            localStorage.setItem('utc_system_heat', this.systemHeat);

            this.checkCriticalEnergy();
        }, 1000);
    }

    stopDecay() {
        if (this.decayInterval) {
            clearInterval(this.decayInterval);
        }
    }

    useEnergy(amount) {
        this.currentEnergy = Math.max(this.minEnergy, this.currentEnergy - amount);
        this.systemHeat = Math.min(this.maxEnergy, this.systemHeat + amount * 1.5);
        this.stateManager.setNestedState('modules.energy.currentEnergy', this.currentEnergy);
        this.stateManager.setNestedState('modules.energy.systemHeat', this.systemHeat);
        localStorage.setItem('utc_energy_level', this.currentEnergy);
        localStorage.setItem('utc_system_heat', this.systemHeat);
    }

    addEnergy(amount) {
        this.currentEnergy = Math.min(this.maxEnergy, this.currentEnergy + amount);
        this.stateManager.setNestedState('modules.energy.currentEnergy', this.currentEnergy);
        localStorage.setItem('utc_energy_level', this.currentEnergy);
    }

    checkCriticalEnergy() {
        if (this.currentEnergy < this.criticalThreshold) {
            this.eventBus.publish('energy:critical_low', this.currentEnergy);
            this.eventBus.publish('notification', { message: 'KRİTİK ENERJİ SEVİYESİ!', type: 'error' });
            this.eventBus.publish('log', 'Kritik enerji seviyesi, sistem performansı düşürülüyor.');
        } else if (this.currentEnergy > this.criticalThreshold && this.stateManager.getNestedState('modules.energy.isCritical')) {
            this.eventBus.publish('energy:critical_end');
            this.eventBus.publish('log', 'Enerji seviyesi normale döndü, performans artırılıyor.');
        }
        this.stateManager.setNestedState('modules.energy.isCritical', this.currentEnergy < this.criticalThreshold);
    }

    boostEnergy() {
        this.addEnergy(15);
        this.systemHeat = Math.min(this.maxEnergy, this.systemHeat + 10);
        this.stateManager.setNestedState('modules.energy.systemHeat', this.systemHeat);
        localStorage.setItem('utc_system_heat', this.systemHeat);
        this.eventBus.publish('log', 'Sistem enerjisi güçlendirildi.');
    }

    optimizeEnergy() {
        this.systemHeat = Math.max(0, this.systemHeat - 20);
        this.stateManager.setNestedState('modules.energy.systemHeat', this.systemHeat);
        localStorage.setItem('utc_system_heat', this.systemHeat);
        const originalDecayRate = this.decayRate;
        this.decayRate *= 0.8;
        setTimeout(() => {
            this.decayRate = originalDecayRate;
        }, 30000);
        this.eventBus.publish('log', 'Sistem enerjisi optimize edildi.');
    }

    recycleEnergy() {
        let recycledAmount = 5;
        this.addEnergy(recycledAmount);
        this.eventBus.publish('log', `Enerji geri dönüşümü tamamlandı. ${recycledAmount}% enerji kazanıldı.`);
    }
}

export { EnergyReactor };
