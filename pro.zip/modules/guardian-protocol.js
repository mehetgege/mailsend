// modules/guardian-protocol.js

class GuardianProtocol {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.killSwitchActive = false;
        this.autoRecovered = false;

        this.eventBus.subscribe('risk:metrics_updated', (metrics) => this.checkKillSwitch(metrics));
        this.eventBus.subscribe('system:start', () => this.onSystemStart());
        this.eventBus.publish('log', 'Guardian Protocol başlatıldı.');
    }

    init() {
        // Durumu yükle veya başlat
        const savedState = localStorage.getItem('utc_guardian_state');
        if (savedState) {
            try {
                const state = JSON.parse(savedState);
                this.killSwitchActive = state.killSwitchActive;
                this.autoRecovered = state.autoRecovered;
            } catch (e) {
                this.eventBus.publish('log', 'Guardian Protocol durum bilgisi yüklenirken hata oluştu.', 'error');
            }
        }
    }
    
    saveState() {
        const state = {
            killSwitchActive: this.killSwitchActive,
            autoRecovered: this.autoRecovered
        };
        localStorage.setItem('utc_guardian_state', JSON.stringify(state));
    }
    
    onSystemStart() {
        // Sistem yeniden başladığında kill switch durumunu kontrol et
        if (this.killSwitchActive && !this.stateManager.getNestedState('settings.riskGuardian.autoRecover')) {
            this.eventBus.publish('system:stop_requested');
            this.eventBus.publish('notification', { message: 'ACİL DURDURMA: Sistem manuel olarak durduruldu.', type: 'danger' });
            this.eventBus.publish('log', 'Sistem durduruldu çünkü "kill switch" aktif ve otomatik kurtarma devre dışı.', 'warn');
        }
    }

    checkKillSwitch(metrics) {
        const settings = this.stateManager.getState('settings');
        const winRateThreshold = settings?.riskGuardian?.killSwitchWinRate || 35.0;
        const enableRiskGuardian = settings?.features?.enableRiskGuardian;
        const autoRecoverEnabled = settings?.riskGuardian?.autoRecover;
        const minSignals = 10;
        
        if (!enableRiskGuardian) {
            this.killSwitchActive = false;
            this.saveState();
            return;
        }

        if (metrics.total >= minSignals) {
            if (metrics.winRate < winRateThreshold && !this.killSwitchActive) {
                this.killSwitchActive = true;
                this.autoRecovered = false;
                this.saveState();
                
                this.eventBus.publish('log', `KRİTİK HATA: Kazanma oranı eşiğin altında! (%${metrics.winRate.toFixed(1)})`, 'error');
                this.eventBus.publish('notification', { message: 'ACİL DURDURMA PROTOKOLÜ AKTİF!', type: 'error', priority: 5 });
                this.eventBus.publish('system:stop_requested');
            } else if (metrics.winRate > winRateThreshold + 5 && this.killSwitchActive && autoRecoverEnabled && !this.autoRecovered) {
                this.autoRecovered = true;
                this.saveState();
                
                this.eventBus.publish('log', 'Sistem risk seviyesi normale döndü, otomatik kurtarma deneniyor.', 'warn');
                this.eventBus.publish('notification', { message: 'OTOMATİK KURTARMA BAŞLATILDI!', type: 'warning', priority: 4 });
                
                // 30 saniye sonra sistemi otomatik olarak başlat
                setTimeout(() => {
                    this.killSwitchActive = false;
                    this.saveState();
                    this.eventBus.publish('system:start_requested');
                    this.eventBus.publish('notification', { message: 'ACİL DURDURMA PROTOKOLÜ DEVRE DIŞI. Sistem yeniden başladı.', type: 'success', priority: 4 });
                }, 30000);
            }
        }
    }
}

export { GuardianProtocol };
