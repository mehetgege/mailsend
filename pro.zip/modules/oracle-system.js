// modules/oracle-system.js

class OracleSystem {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.currentRegime = 'NORMAL';
        
        this.eventBus.subscribe('system:start', () => this.startOracle());
        this.eventBus.subscribe('websocket:message', (data) => this.onCandleData(data));
        this.eventBus.subscribe('data:candles_loaded', (candles) => this.recalculateAllMetrics(candles));
    }

    init() {
        this.stateManager.setNestedState('marketData.regime', this.currentRegime);
        this.eventBus.publish('log', 'Oracle System başlatıldı.');
    }
    
    recalculateAllMetrics(candles) {
        if (candles.length > 20) {
            this.detectMarketRegime();
        }
    }

    startOracle() {
        this.oracleInterval = setInterval(() => this.detectMarketRegime(), 60000);
    }
    
    stopOracle() {
        if (this.oracleInterval) {
            clearInterval(this.oracleInterval);
        }
    }

    onCandleData(data) {
        if (data.stream.includes('@kline') && data.data.k) {
            const candles = this.stateManager.getNestedState('marketData.candles');
            const newCandle = {
                time: data.data.k.t,
                open: parseFloat(data.data.k.o),
                high: parseFloat(data.data.k.h),
                low: parseFloat(data.data.k.l),
                close: parseFloat(data.data.k.c),
                volume: parseFloat(data.data.k.v)
            };
            if (candles.length > 0 && candles[candles.length - 1].time === newCandle.time) {
                candles[candles.length - 1] = newCandle;
            } else {
                candles.push(newCandle);
                if (candles.length > 500) candles.shift();
            }
            this.stateManager.setNestedState('marketData.candles', candles);
            
            if (data.data.k.x) { // Mum kapandığında
                this.detectMarketRegime();
            }
        }
    }

    detectMarketRegime() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        const indicators = this.stateManager.getNestedState('marketData.indicators');
        
        if (!candles || candles.length < 20 || !indicators?.atr) {
            this.currentRegime = 'NORMAL';
            return;
        }

        const prices = candles.slice(-20).map(c => c.close);
        const volumes = candles.slice(-20).map(c => c.volume);
        
        const trendStrength = this.calculateTrendStrength(prices);
        const atrPercentage = (indicators.atr / prices[prices.length - 1]) * 100;
        const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;
        const recentVolume = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
        const priceChange = ((prices[prices.length - 1] - prices[0]) / prices[0]) * 100;
        
        const previousRegime = this.currentRegime;

        if (priceChange < -5 && atrPercentage > 3) {
            this.currentRegime = 'ÖLÜM';
        } else if (Math.abs(trendStrength) > 0.7 && atrPercentage > 2) {
            this.currentRegime = 'SAVAŞ';
        } else if (atrPercentage > 2 && Math.abs(trendStrength) < 0.3) {
            this.currentRegime = 'SALGIN';
        } else if (atrPercentage < 1 && recentVolume < avgVolume * 0.7) {
            this.currentRegime = 'KITLIK';
        } else {
            this.currentRegime = 'NORMAL';
        }

        if (this.currentRegime !== previousRegime) {
            this.stateManager.setNestedState('marketData.regime', this.currentRegime);
            this.eventBus.publish('oracle:regime_changed', this.currentRegime);
            this.eventBus.publish('log', `Piyasa rejimi değişti: ${this.currentRegime}`);
        }
    }
    
    calculateVolatility(prices) {
        if (prices.length < 2) return 0;
        const avg = prices.reduce((sum, p) => sum + p, 0) / prices.length;
        const variance = prices.map(p => (p - avg) ** 2).reduce((sum, v) => sum + v, 0) / (prices.length - 1);
        const stdDev = Math.sqrt(variance);
        return (stdDev / avg) * 100;
    }
    
    calculateTrendStrength(prices) {
        const n = prices.length;
        let [sumX, sumY, sumXY, sumX2] = [0, 0, 0, 0];
        for (let i = 0; i < n; i++) {
            sumX += i;
            sumY += prices[i];
            sumXY += i * prices[i];
            sumX2 += i * i;
        }
        const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        return (slope / prices[0]) * 100;
    }
}

export { OracleSystem };
