// modules/pantheon-council.js

class PantheonCouncil {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.ambassadors = {};
        
        this.eventBus.subscribe('signal:final', (signal) => this.awardPower(signal));
        this.eventBus.subscribe('oracle:regime_changed', (regime) => this.adaptToRegime(regime));
    }

    init() {
        this.defineAmbassadors();
        this.loadState();
        this.eventBus.publish('log', 'Pantheon Council başlatıldı.');
    }

    defineAmbassadors() {
        const baseAmbassador = { reputation: 0, power: 0, active: true, name: '', role: '', color: '' };
        this.ambassadors = {
            metatron: { ...baseAmbassador, name: 'Metatron', role: 'wisdom', color: 'var(--metatron-color)' },
            uriel: { ...baseAmbassador, name: 'Uriel', role: 'courage', color: 'var(--uriel-color)' },
            raphael: { ...baseAmbassador, name: 'Raphael', role: 'healing', color: 'var(--raphael-color)' },
            gabriel: { ...baseAmbassador, name: 'Gabriel', role: 'communication', color: 'var(--gabriel-color)' },
            michael: { ...baseAmbassador, name: 'Michael', role: 'warfare', color: 'var(--michael-color)' }
        };
        this.stateManager.setState('pantheonState', this.ambassadors);
    }

    loadState() {
        const savedState = JSON.parse(localStorage.getItem('pantheonState') || '{}');
        Object.assign(this.ambassadors, savedState);
        this.stateManager.setState('pantheonState', this.ambassadors);
    }

    awardPower(signal) {
        const { direction, contributors } = signal;
        let powerAwarded = direction === 'buy' ? 5 : 3;

        contributors.forEach(contributor => {
            const ambassador = this.findAmbassadorByStrategy(contributor.strategy);
            if (ambassador) {
                ambassador.power += powerAwarded;
                this.eventBus.publish('pantheon:power_awarded', { ambassador: ambassador.name, amount: powerAwarded });
            }
        });

        this.stateManager.setState('pantheonState', this.ambassadors);
        this.saveState();
    }

    adaptToRegime(regime) {
        this.eventBus.publish('pantheon:regime_adapted', regime);
        this.eventBus.publish('log', `Pantheon, yeni rejim olan ${regime}e adapte oluyor.`);
    }

    findAmbassadorByStrategy(strategyName) {
        const wisdomStrategies = ['SupportResistanceStrategy', 'FibonacciRetracementStrategy', 'VWAPReversionStrategy', 'MicroSpreadArbitrageStrategy', 'RsiDivergenceStrategy'];
        const courageStrategies = ['BreakoutPatternStrategy', 'VelocityScalpingStrategy', 'VolatilityBreakoutStrategy', 'SuperTrendStrategy', 'MarketStructureStrategy'];
        const healingStrategies = ['LiquidityGapsStrategy', 'OrderFlowMomentumStrategy', 'InstitutionalOrderFlowStrategy'];
        const communicationStrategies = ['SmartMoneyConceptsStrategy', 'CandleCharacterStrategy', 'FundingRateReversalStrategy'];
        const warfareStrategies = ['DivergenceDetectionStrategy', 'VolumeProfileStrategy'];

        if (wisdomStrategies.includes(strategyName)) return this.ambassadors.metatron;
        if (courageStrategies.includes(strategyName)) return this.ambassadors.uriel;
        if (healingStrategies.includes(strategyName)) return this.ambassadors.raphael;
        if (communicationStrategies.includes(strategyName)) return this.ambassadors.gabriel;
        if (warfareStrategies.includes(strategyName)) return this.ambassadors.michael;
        
        return null;
    }

    saveState() {
        localStorage.setItem('pantheonState', JSON.stringify(this.ambassadors));
    }
}

export { PantheonCouncil };
