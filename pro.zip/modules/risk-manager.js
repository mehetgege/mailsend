// modules/risk-manager.js

class RiskAssessmentManager {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.signals = [];

        this.eventBus.subscribe('signal:final', (signal) => this.addSignal(signal));
        this.eventBus.subscribe('signal:result', (result) => this.updateSignal(result));
        this.eventBus.subscribe('system:start', () => this.startAssessment());
        this.eventBus.publish('log', 'Risk Assessment Manager başlatıldı.');
    }

    init() {
        this.loadState();
    }

    loadState() {
        this.signals = this.stateManager.getState('signals') || [];
    }

    addSignal(signal) {
        this.signals.push(signal);
        this.stateManager.setState('signals', this.signals);
    }

    updateSignal(result) {
        const signal = this.signals.find(s => s.id === result.id);
        if (signal) {
            signal.status = result.status;
            signal.exitPrice = result.exitPrice;
            this.stateManager.setState('signals', this.signals);
            this.calculateRiskMetrics();
        }
    }

    startAssessment() {
        this.assessmentInterval = setInterval(() => this.calculateRiskMetrics(), 300000);
    }

    calculateRiskMetrics() {
        const completedSignals = this.signals.filter(s => s.status === 'tp' || s.status === 'sl');
        const winCount = completedSignals.filter(s => s.status === 'tp').length;
        const totalCount = completedSignals.length;
        let winRate = 0;
        let totalProfit = 0;
        let totalLoss = 0;
        if (totalCount > 0) {
            winRate = (winCount / totalCount) * 100;
        }

        completedSignals.forEach(s => {
            const entryPrice = s.price;
            const exitPrice = s.exitPrice || this.stateManager.getNestedState('marketData.price');
            const pnl = (s.direction === 'buy' ? 1 : -1) * (exitPrice - entryPrice);
            if (pnl > 0) {
                totalProfit += pnl;
            } else {
                totalLoss += Math.abs(pnl);
            }
        });

        const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? Infinity : 0;

        const stats = {
            winRate: winRate,
            total: totalCount,
            wins: winCount,
            losses: totalCount - winCount,
            profitFactor: profitFactor
        };

        this.stateManager.setState('stats', stats);
        this.eventBus.publish('risk:metrics_updated', stats);
    }
}

export { RiskAssessmentManager };
