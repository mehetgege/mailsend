// modules/ritual-engine.js

class RitualEngine {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.rituals = this.getRitualDefinitions();
        this.activeRitual = null;
        this.ritualIntervals = {};
        
        this.eventBus.subscribe('ui:prepare_ritual', (ritualId) => this.prepareRitual(ritualId));
        this.eventBus.subscribe('ui:activate_ritual', (ritualId) => this.activateRitual(ritualId));
        this.eventBus.subscribe('system:stop', () => this.stopAllRitualTimers());
    }

    init() {
        this.loadState();
        this.checkActiveRituals();
        this.eventBus.publish('log', 'Ritual Engine başlatıldı.');
    }

    getRitualDefinitions() {
        return [
            { id: 'marketHarmony', name: 'Piyasa Uyumu', description: 'Piyasa akışı ile uyumlanma ritüeli. Trend yönünü daha net gösterir ve geçişleri erken yakalar.', effect: 'Trend analiz doğruluğu +25%, trend geçiş tespiti +30%', duration: 15 * 60 * 1000, preparationTime: 60 * 1000, energyCost: 15, type: 'trend', active: false, prepared: false, prepProgress: 0, remainingTime: 0, activatedAt: null },
            { id: 'confluenceRitual', name: 'Uyum Noktası Ritüeli', description: 'Çoklu zaman dilimlerindeki fiyat uyumlarını görme yeteneğini artırır.', effect: 'Uyum skorları +35%, çoklu zaman dilimi doğruluğu +25%', duration: 20 * 60 * 1000, preparationTime: 90 * 1000, energyCost: 20, type: 'confluence', active: false, prepared: false, prepProgress: 0, remainingTime: 0, activatedAt: null },
            { id: 'liquidityVision', name: 'Likidite Görüşü', description: 'Piyasadaki büyük likidite havuzlarını ve emir duvarlarını daha net görmenizi sağlar.', effect: 'Likidite tespiti +40%, büyük emirlerin tespiti +30%', duration: 10 * 60 * 1000, preparationTime: 45 * 1000, energyCost: 12, type: 'liquidity', active: false, prepared: false, prepProgress: 0, remainingTime: 0, activatedAt: null },
            { id: 'orderFlowInsight', name: 'Emir Akışı İçgörüsü', description: 'Piyasa katılımcılarının davranışlarını daha iyi anlama ve emir akışını derinlemesine görme yeteneği.', effect: 'Emir akışı analizi +30%, piyasa katılımcı analizi +25%', duration: 12 * 60 * 1000, preparationTime: 75 * 1000, energyCost: 18, type: 'orderflow', active: false, prepared: false, prepProgress: 0, remainingTime: 0, activatedAt: null },
            { id: 'divineProtection', name: 'İlahi Koruma', description: 'Piyasa manipülasyonlarına karşı koruma sağlar ve ani fiyat hareketlerinden sizi korur.', effect: 'Manipülasyon tespiti +40%, ani hareket koruması +35%', duration: 30 * 60 * 1000, preparationTime: 120 * 1000, energyCost: 25, type: 'protection', active: false, prepared: false, prepProgress: 0, remainingTime: 0, activatedAt: null }
        ];
    }
    
    loadState() {
        const savedState = localStorage.getItem('utc_ritual_states');
        if (savedState) {
            try {
                const ritualStates = JSON.parse(savedState);
                ritualStates.forEach(state => {
                    const ritual = this.rituals.find(r => r.id === state.id);
                    if (ritual) {
                        Object.assign(ritual, state);
                        if (ritual.active && ritual.activatedAt) {
                            const elapsedTime = Date.now() - ritual.activatedAt;
                            ritual.remainingTime = Math.max(0, ritual.duration - elapsedTime);
                            if (ritual.remainingTime <= 0) {
                                ritual.active = false;
                                ritual.activatedAt = null;
                            }
                        }
                        if (ritual.active) this.activeRitual = ritual;
                    }
                });
            } catch (e) {
                this.eventBus.publish('log', 'Ritüel durumları yüklenirken hata oluştu.', 'error');
            }
        }
    }
    
    saveState() {
        const ritualStates = this.rituals.map(ritual => ({
            id: ritual.id, active: ritual.active, prepared: ritual.prepared, prepProgress: ritual.prepProgress, activatedAt: ritual.activatedAt
        }));
        localStorage.setItem('utc_ritual_states', JSON.stringify(ritualStates));
    }
    
    prepareRitual(ritualId) {
        const ritual = this.rituals.find(r => r.id === ritualId);
        if (!ritual) return;
        
        if (this.activeRitual) {
            this.eventBus.publish('notification', { message: 'Zaten aktif bir ritüel var.', type: 'warning' });
            return;
        }
        
        if (ritual.prepared) {
            this.eventBus.publish('notification', { message: `${ritual.name} zaten hazır!`, type: 'info' });
            return;
        }
        
        const currentEnergy = this.stateManager.getNestedState('modules.energy.currentEnergy') || 0;
        if (currentEnergy < ritual.energyCost) {
            this.eventBus.publish('notification', { message: `Yetersiz enerji! ${ritual.energyCost}% enerji gerekiyor.`, type: 'error' });
            return;
        }
        
        ritual.prepProgress = 0;
        this.eventBus.publish('log', `${ritual.name} ritüeli hazırlanıyor...`);
        this.eventBus.publish('energy:use', ritual.energyCost);
        
        const updateInterval = 100;
        const progressStep = (updateInterval / ritual.preparationTime) * 100;
        
        this.prepInterval = setInterval(() => {
            ritual.prepProgress += progressStep;
            
            if (ritual.prepProgress >= 100) {
                ritual.prepProgress = 100;
                ritual.prepared = true;
                clearInterval(this.prepInterval);
                this.prepInterval = null;
                
                this.eventBus.publish('notification', { message: `${ritual.name} ritüeli hazırlandı!`, type: 'success' });
                this.eventBus.publish('log', `${ritual.name} ritüeli hazırlandı.`);
                this.eventBus.publish('ritual:ready', ritual.id);
                this.saveState();
            }
        }, updateInterval);
    }
    
    activateRitual(ritualId) {
        const ritual = this.rituals.find(r => r.id === ritualId);
        if (!ritual || !ritual.prepared || this.activeRitual) return;
        
        ritual.active = true;
        ritual.prepared = false;
        ritual.activatedAt = Date.now();
        ritual.remainingTime = ritual.duration;
        this.activeRitual = ritual;
        
        this.applyRitualEffects(ritual);
        this.startRitualTimer(ritual);
        this.saveState();

        this.eventBus.publish('log', `${ritual.name} ritüeli aktifleştirildi. Süre: ${this.formatTime(ritual.duration)}`);
        this.eventBus.publish('notification', { message: `${ritual.name} ritüeli aktifleştirildi!`, type: 'success' });
        this.eventBus.publish('ritual:activated', ritual.id);
    }
    
    deactivateRitual() {
        if (!this.activeRitual) return;
        
        this.removeRitualEffects(this.activeRitual);
        
        this.eventBus.publish('log', `${this.activeRitual.name} ritüeli sona erdi.`);
        this.eventBus.publish('notification', { message: `${this.activeRitual.name} ritüeli sona erdi.`, type: 'info' });
        this.eventBus.publish('ritual:deactivated', this.activeRitual.id);
        
        this.activeRitual.active = false;
        this.activeRitual.activatedAt = null;
        this.activeRitual.remainingTime = 0;
        this.activeRitual = null;
        this.saveState();
    }
    
    startRitualTimer(ritual) {
        if (this.ritualIntervals[ritual.id]) clearInterval(this.ritualIntervals[ritual.id]);
        
        const updateInterval = 1000;
        
        this.ritualIntervals[ritual.id] = setInterval(() => {
            ritual.remainingTime -= updateInterval;
            
            if (ritual.remainingTime <= 0) {
                this.deactivateRitual();
                clearInterval(this.ritualIntervals[ritual.id]);
                delete this.ritualIntervals[ritual.id];
            }
        }, updateInterval);
    }
    
    stopAllRitualTimers() {
        if (this.prepInterval) clearInterval(this.prepInterval);
        Object.values(this.ritualIntervals).forEach(clearInterval);
        this.ritualIntervals = {};
    }
    
    checkActiveRituals() {
        this.rituals.forEach(ritual => {
            if (ritual.active && ritual.activatedAt) {
                const elapsedTime = Date.now() - ritual.activatedAt;
                ritual.remainingTime = Math.max(0, ritual.duration - elapsedTime);
                if (ritual.remainingTime > 0) {
                    this.applyRitualEffects(ritual);
                    this.startRitualTimer(ritual);
                } else {
                    this.deactivateRitual();
                }
            }
        });
    }

    applyRitualEffects(ritual) {
        switch (ritual.type) {
            case 'trend':
                this.eventBus.publish('ritual:effect_start', { type: 'trend', value: 1.25 });
                break;
            case 'confluence':
                this.eventBus.publish('ritual:effect_start', { type: 'confluence', value: 1.35 });
                break;
            case 'liquidity':
                this.eventBus.publish('ritual:effect_start', { type: 'liquidity', value: 1.4 });
                break;
            case 'orderflow':
                this.eventBus.publish('ritual:effect_start', { type: 'orderflow', value: 1.3 });
                break;
            case 'protection':
                this.eventBus.publish('ritual:effect_start', { type: 'protection', value: 1.35 });
                break;
        }
    }

    removeRitualEffects(ritual) {
        this.eventBus.publish('ritual:effect_end', { type: ritual.type });
    }
    
    formatTime(ms) {
        const totalSeconds = Math.floor(ms / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
}

export { RitualEngine };
