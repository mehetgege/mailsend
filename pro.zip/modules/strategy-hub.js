// modules/strategy-hub.js

import * as Strategies from '../strategies/index.js';

class StrategyHub {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.strategies = {};
        this.allStrategyKeys = Object.keys(Strategies).filter(k => k !== 'Strategy');

        this.eventBus.subscribe('system:start', () => this.startAllStrategies());
        this.eventBus.subscribe('system:stop', () => this.stopAllStrategies());
        this.eventBus.subscribe('websocket:message', (data) => this.distributeData(data));
        this.eventBus.subscribe('state:settings_updated', () => this.updateStrategySettings());
        this.eventBus.subscribe('state:currentSymbol_updated', () => this.updateStrategySettings());
        this.eventBus.subscribe('state:currentTimeframe_updated', () => this.updateStrategySettings());
    }

    init() {
        this.allStrategyKeys.forEach(key => {
            if (Strategies[key].name === 'Strategy') return;
            this.strategies[key] = new Strategies[key](this.eventBus, this.stateManager, key);
        });
        this.updateStrategySettings();
    }

    startAllStrategies() {
        Object.values(this.strategies).forEach(strategy => strategy.start());
    }

    stopAllStrategies() {
        Object.values(this.strategies).forEach(strategy => strategy.stop());
    }

    updateStrategySettings() {
        const settings = this.stateManager.getState('settings');
        Object.values(this.strategies).forEach(strategy => {
            const isActive = settings?.activeStrategies?.[strategy.name];
            strategy.isActive = isActive;
        });
    }

    distributeData(message) {
        const { stream, data } = message;
        if (!data || !stream) return;
        
        Object.values(this.strategies).forEach(strategy => {
            if (strategy.isActive) {
                if (stream.includes('@kline')) {
                    strategy.onCandle(data.k);
                } else if (stream.includes('@depth')) {
                    strategy.onOrderBook(data);
                } else if (stream.includes('@aggTrade')) {
                    strategy.onTrade(data);
                }
            }
        });
    }
}

export { StrategyHub };
