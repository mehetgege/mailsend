// modules/visualizer-core.js

import { ChartManager } from '../visualizers/chart-manager.js';
import { HeatmapManager } from '../visualizers/heatmap-manager.js';

class VisualizerCore {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.chartManager = null;
        this.heatmapManager = null;

        this.eventBus.subscribe('app:ready', () => this.initVisualizers());
        this.eventBus.subscribe('data:candles_loaded', (candles) => this.updateChart(candles));
        this.eventBus.subscribe('websocket:message', (message) => this.onMessage(message));
        this.eventBus.subscribe('signal:final', (signal) => this.addSignalMarker(signal));
        this.eventBus.subscribe('ui:theme_changed', () => this.updateVisualizerThemes());
        this.eventBus.subscribe('ui:clear_chart_markers', () => this.clearMarkers());
        this.eventBus.subscribe('state:marketData.indicators.bbands_updated', (bbandsData) => this.updateBollingerBands(bbandsData));
    }

    initVisualizers() {
        this.chartManager = new ChartManager('live-chart', this.stateManager);
        this.heatmapManager = new HeatmapManager('orderbook-heatmap', this.stateManager);
        this.eventBus.publish('log', 'Visualizer Core başlatıldı.');
    }

    onMessage(message) {
        const { stream, data } = message;
        if (stream.includes('@kline') && data.k) {
            if (data.k.x) { // Mum kapandığında
                this.updateChart(this.stateManager.getNestedState('marketData.candles'));
            } else { // Canlı mum güncellemesi
                this.chartManager.updateRealtime(data.k);
            }
        } else if (stream.includes('@depth')) {
            this.updateHeatmap(data);
        }
    }

    updateChart(candles) {
        if (this.chartManager) {
            this.chartManager.setData(candles);
        }
    }

    updateHeatmap(orderBook) {
        if (this.heatmapManager) {
            this.heatmapManager.draw(orderBook, this.stateManager.getNestedState('marketData.price'));
        }
    }
    
    updateBollingerBands(bbandsData) {
        if (this.chartManager) {
            this.chartManager.drawBollingerBands(bbandsData);
        }
    }

    addSignalMarker(signal) {
        if (this.chartManager) {
            this.chartManager.addMarker(signal);
        }
    }

    clearMarkers() {
        if (this.chartManager) {
            this.chartManager.clearMarkers();
        }
    }

    updateVisualizerThemes() {
        if (this.chartManager) this.chartManager.updateTheme();
        if (this.heatmapManager) this.heatmapManager.updateTheme();
    }
}

export { VisualizerCore };
