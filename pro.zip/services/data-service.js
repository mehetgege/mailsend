// services/data-service.js

class DataService {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.db = null;
        this.DB_NAME = 'TradingWarRoomDB';
        this.DB_VERSION = 1;
        this.dbPromise = null;
    }

    async initDb() {
        if (this.dbPromise) return this.dbPromise;

        this.dbPromise = new Promise((resolve, reject) => {
            if (!window.indexedDB) {
                console.error('IndexedDB bu tarayıcıda desteklenmiyor.');
                return reject(new Error('IndexedDB Not Supported'));
            }

            const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('signals')) {
                    const store = db.createObjectStore('signals', { keyPath: 'id' });
                    store.createIndex('byTimestamp', 'timestamp', { unique: false });
                }
                if (!db.objectStoreNames.contains('stats')) {
                    db.createObjectStore('stats', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('strategyStats')) {
                    db.createObjectStore('strategyStats', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('system')) {
                    db.createObjectStore('system', { keyPath: 'id' });
                }
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                resolve(this.db);
            };

            request.onerror = (event) => {
                console.error('IndexedDB hatası:', event.target.error);
                reject(event.target.error);
            };
        });

        return this.dbPromise;
    }

    async loadInitialData() {
        await this.initDb();

        try {
            const savedSymbol = await this.get('system', 'currentSymbol') || { data: 'BTCUSDT' };
            this.stateManager.setState('currentSymbol', savedSymbol.data);

            const savedTimeframe = await this.get('system', 'currentTimeframe') || { data: '15m' };
            this.stateManager.setState('currentTimeframe', savedTimeframe.data);
            
            const savedSettings = await this.get('settings', 'global') || {};
            this.stateManager.setState('settings', savedSettings.data || this.stateManager.getState('settings'));

            const savedStats = await this.get('stats', 'global') || {};
            this.stateManager.setState('stats', savedStats.data || this.stateManager.getState('stats'));

            const savedStrategyStats = await this.get('strategyStats', 'global') || {};
            this.stateManager.setState('strategyStats', savedStrategyStats.data || this.stateManager.getState('strategyStats'));

            const savedSignals = await this.getAll('signals');
            if (savedSignals) {
                this.stateManager.setState('signals', savedSignals);
            }
        } catch (error) {
            console.warn('Veritabanından ilk veriler yüklenirken hata oluştu:', error);
        }
    }

    async getHistoricalCandles(symbol, timeframe, limit = 500) {
        try {
            this.eventBus.publish('log', `${symbol} için geçmiş mum verileri çekiliyor...`);
            const response = await fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${timeframe}&limit=${limit}`);
            if (!response.ok) throw new Error(`API Hatası: ${response.statusText}`);
            const data = await response.json();
            const candles = data.map(d => ({
                time: d[0],
                open: parseFloat(d[1]),
                high: parseFloat(d[2]),
                low: parseFloat(d[3]),
                close: parseFloat(d[4]),
                volume: parseFloat(d[5]),
            }));
            this.stateManager.setNestedState('marketData.candles', candles);
            this.eventBus.publish('data:candles_loaded', candles);
            this.eventBus.publish('log', `${candles.length} adet mum yüklendi.`);
            return candles;
        } catch (error) {
            this.eventBus.publish('log', `Geçmiş veri alınamadı: ${error.message}`, 'error');
            return [];
        }
    }

    async put(storeName, data, key = 'global') {
        await this.initDb();
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put({ id: key, data: data, timestamp: Date.now() });

            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }

    async get(storeName, key = 'global') {
        await this.initDb();
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.get(key);

            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }

    async getAll(storeName) {
        await this.initDb();
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }

    async clearStore(storeName) {
        await this.initDb();
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.clear();

            request.onsuccess = () => resolve(request.result);
            request.onerror = (event) => reject(event.target.error);
        });
    }
}

export { DataService };
