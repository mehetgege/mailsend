// services/event-bus.js

class EventBus {
    constructor() {
        this.listeners = new Map();
    }

    publish(event, data) {
        if (this.listeners.has(event)) {
            this.listeners.get(event).forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Event handler for ${event} failed:`, error);
                }
            });
        }
    }

    subscribe(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
    }
}

export { EventBus };