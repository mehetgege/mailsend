// services/logger-service.js

class LoggerService {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.logLevels = {
            INFO: 'info',
            WARN: 'warn',
            ERROR: 'error',
            DEBUG: 'debug'
        };

        this.eventBus.subscribe('log', (entry) => this.displayLog(entry));
    }

    log(message, level = this.logLevels.INFO) {
        const timestamp = new Date().toISOString();
        const logEntry = { message, level, timestamp };
        this.eventBus.publish('log', logEntry);
    }

    info(message) { this.log(message, this.logLevels.INFO); }
    warn(message) { this.log(message, this.logLevels.WARN); }
    error(message, error) { this.log(message, this.logLevels.ERROR); console.error(error); }
    debug(message) { this.log(message, this.logLevels.DEBUG); }

    displayLog(entry) {
        const logOutput = document.getElementById('log-output');
        if (logOutput) {
            const entryElement = document.createElement('div');
            entryElement.textContent = `[${new Date(entry.timestamp).toLocaleTimeString()}] [${entry.level.toUpperCase()}] ${entry.message}`;
            entryElement.className = `log-${entry.level}`;
            logOutput.appendChild(entryElement);
            logOutput.scrollTop = logOutput.scrollHeight;
        }
        if (entry.level === this.logLevels.ERROR) {
            console.error(entry.message);
        } else if (entry.level === this.logLevels.WARN) {
            console.warn(entry.message);
        } else {
            console.log(entry.message);
        }
    }
}

export { LoggerService };
