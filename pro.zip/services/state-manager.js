// services/state-manager.js

class StateManager {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.state = {
            isRunning: false,
            currentSymbol: 'BTCUSDT',
            currentTimeframe: '15m',
            settings: {
                confluenceThreshold: 3,
                params: { rsiPeriod: 14, atrPeriod: 14, wallBtc: 20, rrRatio: 1.5 },
                cooldowns: { signalMs: 15000, sameDirectionMs: 30000, oppositeDirectionMs: 20000, reverseHysteresisPoints: 2, proposalTimeoutMs: 3000, strategyProposalMs: 10000 },
                features: { 
                    enableSpoofDetection: true, enableCUSUMDrift: true, enableRiskGuardian: true, enableTTS: true, preferredVoiceName: null,
                    enableCandleConfirm: true,
                    enableMtfConfirm: true,
                    mtfTimeframe: '15m',
                    enableDynamicSizing: true
                },
                riskGuardian: {
                    killSwitchWinRate: 35.0,
                    autoRecover: false,
                    maxDrawdown: 5.0
                },
                optimization: {
                    enabled: true,
                    autoToggle: true,
                    timeDecaySec: 3,
                    dirMargin: 0.5,
                    minWeightToStay: 0.60,
                    minContribForToggle: 30,
                    gating: { enabled: true, spreadMaxPct: 0.001, minDepthUsd: 50000 },
                    signalQuality: { minContributors: 2, minGroups: 1 },
                    breakeven: { enabled: true, beAtR: 0.8, trailAfterR: 1.5, trailToR: 0.5 }
                },
                penalties: {
                    shadowEnabled: true,
                    minWeightToShadow: 0.60,
                    minContribForShadow: 30,
                    rehabWinRate: 0.58,
                    minShadowProposals: 20,
                    coolOffMs: 30 * 60 * 1000
                },
                statusMaps: {
                    shadowBanned: {},
                    hardBanned: {}
                },
                activeStrategies: {} 
            },
            marketData: {
                price: 0,
                change24h: 0,
                volume24h: 0,
                candles: [],
                indicators: {
                    rsi: [], atr: null, sma20: null, sma50: null, volSma20: null, vwap: null, adx: null, bbands: null
                },
                orderBook: null,
                regime: 'NORMAL'
            },
            signals: [],
            pendingSignals: [],
            stats: { total: 0, tp: 0, sl: 0, profitFactor: 0 },
            strategyStats: {},
            ui: {
                theme: 'dark',
                headerCollapsed: true,
                currentMainView: 'chart'
            }
        };
    }

    getState(key) {
        return this.state[key];
    }

    setState(key, value) {
        this.state[key] = value;
        this.eventBus.publish(`state:${key}_updated`, value);
    }

    getNestedState(keyPath) {
        return keyPath.split('.').reduce((obj, key) => (obj && obj[key] !== undefined) ? obj[key] : undefined, this.state);
    }

    setNestedState(keyPath, value) {
        const keys = keyPath.split('.');
        const lastKey = keys.pop();
        const target = keys.reduce((obj, key) => obj[key], this.state);
        if (target) {
            target[lastKey] = value;
            this.eventBus.publish(`state:${keyPath}_updated`, value);
        }
    }
}

export { StateManager };
