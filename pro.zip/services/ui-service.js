// services/ui-service.js

class UIService {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.elements = {};
        this.ttsVoiceSelect = null;
    }

    init() {
        this.cacheDOMElements();
        this.bindGlobalEvents();
        this.setupStateSubscriptions();
        this.updateUIFromState();
        this.updateCandleCountdown();
        this.countdownInterval = setInterval(() => this.updateCandleCountdown(), 1000);
        this.loadTTSVoices();
    }

    cacheDOMElements() {
        this.elements = {
            startBtn: document.getElementById('start-btn'),
            stopBtn: document.getElementById('stop-btn'),
            themeToggleBtn: document.getElementById('theme-toggle-btn'),
            symbolInput: document.getElementById('symbol-input'),
            timeframeSelect: document.getElementById('timeframe-select'),
            connectionStatusDot: document.getElementById('connection-status'),
            connectionText: document.getElementById('connection-text'),
            currentPrice: document.getElementById('current-price'),
            tickerPrice: document.getElementById('ticker-bar-price'),
            priceChange: document.getElementById('price-change-24h'),
            volume24h: document.getElementById('volume-24h'),
            atrValue: document.getElementById('atr-value'),
            candleCountdown: document.getElementById('candle-countdown'),
            chartCountdownOverlay: document.getElementById('chart-countdown-overlay'),
            buySignalScore: document.getElementById('buy-signal-score-text'),
            sellSignalScore: document.getElementById('sell-signal-score-text'),
            buySignalBar: document.getElementById('buy-signal-bar-fill'),
            sellSignalBar: document.getElementById('sell-signal-bar-fill'),
            settingsModal: document.getElementById('settings-modal-overlay'),
            closeSettingsBtn: document.getElementById('close-settings-modal-btn'),
            saveSettingsBtn: document.getElementById('save-settings-btn'),
            resetSettingsBtn: document.getElementById('reset-all-settings-btn'),
            logModal: document.getElementById('log-modal-overlay'),
            closeLogBtn: document.getElementById('close-log-modal-btn'),
            exportLogsBtn: document.getElementById('export-logs-btn'),
            honorModal: document.getElementById('honor-modal-overlay'),
            closeHonorBtn: document.getElementById('close-honor-modal'),
            mainViewChart: document.getElementById('chart-container-view'),
            mainViewHeatmap: document.getElementById('heatmap-container-view'),
            mainControlsBtn: document.getElementById('main-controls-btn'),
            chartViewBtn: document.getElementById('chart-view-btn'),
            heatmapViewBtn: document.getElementById('heatmap-view-btn'),
            fullscreenChartBtn: document.getElementById('fullscreen-chart-btn'),
            exitFullscreenBtn: document.getElementById('exit-fullscreen-btn'),
            headerTopBar: document.getElementById('header-main-bar')
        };
        this.ttsVoiceSelect = document.getElementById('modal-tts-voice-select');
    }

    bindGlobalEvents() {
        if (this.elements.startBtn) this.elements.startBtn.addEventListener('click', () => this.eventBus.publish('ui:start_clicked'));
        if (this.elements.stopBtn) this.elements.stopBtn.addEventListener('click', () => this.eventBus.publish('ui:stop_clicked'));
        if (this.elements.themeToggleBtn) this.elements.themeToggleBtn.addEventListener('click', () => this.toggleTheme());
        if (this.elements.symbolInput) this.elements.symbolInput.addEventListener('change', (e) => this.eventBus.publish('ui:symbol_changed', e.target.value));
        if (this.elements.timeframeSelect) this.elements.timeframeSelect.addEventListener('change', (e) => this.eventBus.publish('ui:timeframe_changed', e.target.value));
        
        if (this.elements.headerTopBar) {
            this.elements.headerTopBar.addEventListener('dblclick', () => this.eventBus.publish('ui:toggle_header'));
        }
        if (this.elements.mainControlsBtn) this.elements.mainControlsBtn.addEventListener('click', () => this.eventBus.publish('ui:toggle_header'));
        
        if (this.elements.chartViewBtn) this.elements.chartViewBtn.addEventListener('click', () => this.eventBus.publish('ui:view_changed', 'chart'));
        if (this.elements.heatmapViewBtn) this.elements.heatmapViewBtn.addEventListener('click', () => this.eventBus.publish('ui:view_changed', 'heatmap'));
        
        if (this.elements.fullscreenChartBtn) this.elements.fullscreenChartBtn.addEventListener('click', () => this.eventBus.publish('ui:toggle_fullscreen_chart', true));
        if (this.elements.exitFullscreenBtn) this.elements.exitFullscreenBtn.addEventListener('click', () => this.eventBus.publish('ui:toggle_fullscreen_chart', false));

        document.getElementById('open-settings-modal-btn')?.addEventListener('click', () => this.toggleModal(this.elements.settingsModal, true));
        this.elements.closeSettingsBtn?.addEventListener('click', () => this.toggleModal(this.elements.settingsModal, false));
        this.elements.saveSettingsBtn?.addEventListener('click', () => this.eventBus.publish('ui:save_settings'));
        this.elements.resetSettingsBtn?.addEventListener('click', () => this.eventBus.publish('ui:reset_all_settings'));
        
        document.getElementById('open-log-modal-btn')?.addEventListener('click', () => this.toggleModal(this.elements.logModal, true));
        this.elements.closeLogBtn?.addEventListener('click', () => this.toggleModal(this.elements.logModal, false));
        this.elements.exportLogsBtn?.addEventListener('click', () => this.eventBus.publish('ui:export_logs'));
        
        document.getElementById('honor-board-btn')?.addEventListener('click', () => this.eventBus.publish('ui:open_honor_board'));
        this.elements.closeHonorBtn?.addEventListener('click', () => this.toggleModal(this.elements.honorModal, false));

        if (this.elements.ttsVoiceSelect) {
            this.elements.ttsVoiceSelect.addEventListener('change', (e) => this.eventBus.publish('ui:tts_voice_changed', e.target.value));
        }

        window.addEventListener('resize', () => this.eventBus.publish('ui:window_resized'));
    }

    setupStateSubscriptions() {
        this.eventBus.subscribe('state:marketData_updated', () => this.updatePriceDisplay());
        this.eventBus.subscribe('state:modules.confluence_updated', () => this.updateSignalDisplay());
        this.eventBus.subscribe('state:isRunning_updated', (isRunning) => this.toggleButtons(isRunning));
        this.eventBus.subscribe('state:ui.theme_updated', () => this.applyTheme());
        this.eventBus.subscribe('state:ui.headerCollapsed_updated', (isCollapsed) => this.toggleHeader(isCollapsed));
        this.eventBus.subscribe('state:ui.currentMainView_updated', (view) => this.toggleMainView(view));
        this.eventBus.subscribe('websocket:connected', () => this.updateConnectionStatus(true));
        this.eventBus.subscribe('websocket:disconnected', () => this.updateConnectionStatus(false));
    }
    
    updateUIFromState() {
        const state = this.stateManager.state;
        if (this.elements.symbolInput) this.elements.symbolInput.value = state.currentSymbol.replace('USDT', '');
        if (this.elements.timeframeSelect) this.elements.timeframeSelect.value = state.currentTimeframe;
        this.toggleButtons(state.isRunning);
        this.applyTheme();
        this.toggleHeader(state.ui.headerCollapsed);
        this.toggleMainView(state.ui.currentMainView);
        this.updatePriceDisplay();
        this.updateSignalDisplay();
    }

    applyTheme() {
        const theme = this.stateManager.getNestedState('ui.theme');
        document.documentElement.setAttribute('data-theme', theme);
        this.eventBus.publish('ui:theme_changed', theme);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        let newTheme;
        if (currentTheme === 'dark') {
            newTheme = 'light';
        } else if (currentTheme === 'light') {
            newTheme = 'war';
        } else {
            newTheme = 'dark';
        }
        this.stateManager.setNestedState('ui.theme', newTheme);
    }

    toggleButtons(isRunning) {
        if (this.elements.startBtn) this.elements.startBtn.disabled = isRunning;
        if (this.elements.stopBtn) this.elements.stopBtn.disabled = !isRunning;
    }

    toggleHeader(isCollapsed) {
        document.body.classList.toggle('header-collapsed', isCollapsed);
        this.eventBus.publish('ui:window_resized');
    }

    toggleMainView(viewName) {
        if (this.elements.mainViewChart) this.elements.mainViewChart.classList.toggle('hidden-view', viewName !== 'chart');
        if (this.elements.mainViewHeatmap) this.elements.mainViewHeatmap.classList.toggle('hidden-view', viewName !== 'heatmap');
        this.eventBus.publish('ui:window_resized');
    }

    updatePriceDisplay() {
        const price = this.stateManager.getNestedState('marketData.price');
        const change24h = this.stateManager.getNestedState('marketData.change24h');
        const volume24h = this.stateManager.getNestedState('marketData.volume24h');
        const atrValue = this.stateManager.getNestedState('marketData.indicators.atr');
        
        if (price) {
            const formattedPrice = this.formatPrice(price);
            if (this.elements.currentPrice) this.elements.currentPrice.textContent = formattedPrice;
            if (this.elements.tickerPrice) {
                const oldPrice = parseFloat(this.elements.tickerPrice.textContent.replace(/,/g, '') || 0);
                this.elements.tickerPrice.textContent = formattedPrice;
                if (price > oldPrice) this.elements.tickerPrice.style.color = 'var(--positive)';
                else if (price < oldPrice) this.elements.tickerPrice.style.color = 'var(--negative)';
                setTimeout(() => this.elements.tickerPrice.style.color = '', 500);
            }
        }
        if (this.elements.priceChange) {
            this.elements.priceChange.textContent = change24h ? `${change24h.toFixed(2)}%` : '-';
            this.elements.priceChange.style.color = change24h >= 0 ? 'var(--positive)' : 'var(--negative)';
        }
        if (this.elements.volume24h) this.elements.volume24h.textContent = volume24h ? this.formatVolume(volume24h) : '-';
        if (this.elements.atrValue) this.elements.atrValue.textContent = atrValue ? atrValue.toFixed(this.getDecimalPlaces(atrValue)) : '-';
    }

    updateCandleCountdown() {
        const countdownEl = this.elements.candleCountdown;
        const overlayEl = this.elements.chartCountdownOverlay;
        const timeframe = this.stateManager.getState('currentTimeframe');
        const candles = this.stateManager.getNestedState('marketData.candles');

        if (!candles || candles.length === 0) return;
        
        const lastCandleOpenTime = candles[candles.length - 1].time;
        const timeframeMs = this.timeframeToMs(timeframe);
        const now = Date.now();
        const nextCandleOpenTime = lastCandleOpenTime + timeframeMs;
        let remainingTime = nextCandleOpenTime - now;

        if (remainingTime < 0 || remainingTime > timeframeMs) {
             remainingTime = timeframeMs - (now % timeframeMs);
        }

        const minutes = Math.floor(remainingTime / 60000);
        const seconds = Math.floor((remainingTime % 60000) / 1000);
        const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        if (countdownEl) countdownEl.textContent = formattedTime;
        if (overlayEl) overlayEl.textContent = formattedTime;
    }

    updateSignalDisplay() {
        const buyScore = this.stateManager.getNestedState('modules.confluence.buyScore') || 0;
        const sellScore = this.stateManager.getNestedState('modules.confluence.sellScore') || 0;

        if (this.elements.buySignalScore) this.elements.buySignalScore.textContent = buyScore.toFixed(1);
        if (this.elements.sellSignalScore) this.elements.sellSignalScore.textContent = sellScore.toFixed(1);

        if (this.elements.buySignalBar) this.elements.buySignalBar.style.width = `${Math.min(100, buyScore * 10)}%`;
        if (this.elements.sellSignalBar) this.elements.sellSignalBar.style.width = `${Math.min(100, sellScore * 10)}%`;
    }

    toggleModal(modalElement, show) {
        if (!modalElement) return;
        if (show) {
            modalElement.classList.add('visible');
        } else {
            modalElement.classList.remove('visible');
        }
    }

    updateConnectionStatus(isConnected, message = 'BAĞLANTI YOK') {
        if (this.elements.connectionStatusDot) {
            this.elements.connectionStatusDot.classList.toggle('online', isConnected);
        }
        if (this.elements.connectionText) {
            this.elements.connectionText.textContent = isConnected ? 'BAĞLI' : message;
            this.elements.connectionText.style.color = isConnected ? 'var(--positive)' : 'var(--negative)';
        }
    }
    
    loadTTSVoices() {
        const synth = window.speechSynthesis;
        if (!synth || !this.ttsVoiceSelect) return;
        const voices = synth.getVoices();
        if (voices.length === 0) {
            synth.onvoiceschanged = () => this.updateTTSVoiceSelectUI(synth.getVoices());
        } else {
            this.updateTTSVoiceSelectUI(voices);
        }
    }

    updateTTSVoiceSelectUI(voices) {
        if (!this.ttsVoiceSelect) return;
        const currentVoiceName = this.stateManager.getNestedState('settings.features.preferredVoiceName');
        this.ttsVoiceSelect.innerHTML = '<option value="">Otomatik Seç</option>';
        if (voices && voices.length > 0) {
            voices.forEach(voice => {
                if (voice.lang.startsWith('tr')) {
                    const option = document.createElement('option');
                    option.value = voice.name;
                    option.textContent = `${voice.name} (${voice.lang})`;
                    if (currentVoiceName === voice.name) {
                        option.selected = true;
                    }
                    this.ttsVoiceSelect.appendChild(option);
                }
            });
        }
    }

    formatPrice(price) { return price.toLocaleString('en-US', { minimumFractionDigits: this.getDecimalPlaces(price), maximumFractionDigits: this.getDecimalPlaces(price) }); }
    formatVolume(volume) { if (volume >= 1e9) return (volume / 1e9).toFixed(2) + 'B'; if (volume >= 1e6) return (volume / 1e6).toFixed(2) + 'M'; if (volume >= 1e3) return (volume / 1e3).toFixed(2) + 'K'; return volume.toFixed(2); }
    getDecimalPlaces(price) { if (!price) return 2; if (price > 1000) return 2; if (price > 1) return 3; if (price > 0.01) return 4; return 6; }
    timeframeToMs(tf) {
        const unit = tf.slice(-1);
        const val = parseInt(tf.slice(0, -1));
        if (unit === 'm') return val * 60 * 1000;
        if (unit === 'h') return val * 60 * 60 * 1000;
        if (unit === 'd') return val * 24 * 60 * 60 * 1000;
        return 60000;
    }
}

export { UIService };
