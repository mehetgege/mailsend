// services/websocket-service.js

class WebSocketService {
    constructor(eventBus, stateManager) {
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.socket = null;
    }

    connect(symbol, timeframe) {
        const symbolLower = symbol.toLowerCase();
        const streams = [
            `${symbolLower}@kline_${timeframe}`,
            `${symbolLower}@depth20@100ms`,
            `${symbolLower}@aggTrade`,
            `${symbolLower}@ticker`
        ];
        this.socket = new WebSocket(`wss://fstream.binance.com/stream?streams=${streams.join('/')}`);

        this.socket.onopen = () => {
            this.eventBus.publish('websocket:connected');
            this.eventBus.publish('log', 'WebSocket bağlantısı kuruldu.');
        };

        this.socket.onmessage = (event) => {
            const message = JSON.parse(event.data);
            this.eventBus.publish('websocket:message', message);
        };

        this.socket.onerror = (error) => {
            this.eventBus.publish('websocket:error', error);
            this.eventBus.publish('log', 'WebSocket bağlantısında hata oluştu.', 'error');
        };

        this.socket.onclose = (event) => {
            this.eventBus.publish('websocket:disconnected', event);
            this.eventBus.publish('log', 'WebSocket bağlantısı kapandı.', 'warn');
        };
    }

    disconnect() {
        if (this.socket) {
            this.socket.close(1000, 'İstemci tarafından kapatıldı.');
            this.socket = null;
        }
    }
}

export { WebSocketService };
