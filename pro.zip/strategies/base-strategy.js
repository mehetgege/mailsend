// strategies/base-strategy.js

class Strategy {
    constructor(eventBus, stateManager, name) {
        if (new.target === Strategy) {
            throw new TypeError("Strategy sınıfı soyuttur, doğrudan örneği oluşturulamaz.");
        }
        this.eventBus = eventBus;
        this.stateManager = stateManager;
        this.name = name;
        this.isActive = false;
        this.proposalCooldowns = {};
        this.DEFAULT_PROPOSAL_COOLDOWN_MS = 10000;
        this.eventBus.publish('log', `Strateji modülü yüklendi: ${this.name}`);
    }

    init() {
        this.eventBus.publish('log', `${this.name} stratejisi başlatma prosedürü tamamlandı.`);
    }

    start() {
        this.eventBus.publish('log', `${this.name} stratejisi etkinleştirildi.`);
    }

    stop() {
        this.eventBus.publish('log', `${this.name} stratejisi devre dışı bırakıldı.`);
    }

    onCandle(kline) {
    }

    onOrderBook(orderBook) {
    }
    
    onTrade(trade) {
    }
    
    periodicAnalyze() {
    }

    propose(direction, score, reason) {
        const now = Date.now();
        const cooldownKey = `${direction}`;
        const lastProposalTime = this.proposalCooldowns[cooldownKey] || 0;
        const cooldownDuration = this.stateManager.getNestedState('settings.cooldowns.strategyProposalMs') || this.DEFAULT_PROPOSAL_COOLDOWN_MS;

        if (now - lastProposalTime < cooldownDuration) {
            return;
        }

        this.eventBus.publish('strategy:signal_proposal', {
            strategy: this.name,
            direction: direction,
            score: score,
            reason: reason,
            timestamp: now
        });
        
        this.proposalCooldowns[cooldownKey] = now;
    }
}

export { Strategy };
