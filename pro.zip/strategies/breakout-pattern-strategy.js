// strategies/breakout-pattern-strategy.js

import { Strategy } from './base-strategy.js';

export class BreakoutPatternStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.LOOKBACK = 30;
        this.VOL_SPIKE = 1.4;
        this.BREAK_PCT = 0.0003;
        
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) {
                this.periodicAnalyze();
            }
        });
    }

    periodicAnalyze() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        
        // Analiz için en az LOOKBACK + 1 mum gerekir
        if (!candles || candles.length < this.LOOKBACK + 1) return;
        
        // Geriye dönük mumları ve son mumu al
        const lookbackCandles = candles.slice(-this.LOOKBACK - 1, -1);
        const lastCandle = candles[candles.length - 1]; 
        
        const highs = lookbackCandles.map(c => c.high);
        const lows = lookbackCandles.map(c => c.low);
        const volumes = lookbackCandles.map(c => c.volume);
        
        // Geriye dönük dönemdeki en yüksek ve en düşük değerleri bul
        const maxHigh = Math.max(...highs);
        const minLow = Math.min(...lows);

        // Ortalama hacmi hesapla
        if (volumes.length === 0) return;
        const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;
        
        // Boğa Kırılımı kontrolü
        if (lastCandle.close > maxHigh * (1 + this.BREAK_PCT) && lastCandle.volume > avgVolume * this.VOL_SPIKE) {
            this.propose('buy', 4, 'Aralık Üstü Hacimli Kırılım');
        } 
        
        // Ayı Kırılımı kontrolü
        else if (lastCandle.close < minLow * (1 - this.BREAK_PCT) && lastCandle.volume > avgVolume * this.VOL_SPIKE) {
            this.propose('sell', 4, 'Aralık Altı Hacimli Kırılım');
        }
    }
}
