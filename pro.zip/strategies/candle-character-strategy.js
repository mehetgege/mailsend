// strategies/candle-character-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateBB } from '../algorithms/indicators.js';
import { calculateATR } from '../algorithms/indicators.js';
import { calculateVWAP } from '../algorithms/indicators.js';
import { calculateSuperTrend } from '../algorithms/indicators.js';
import { calculateRSI } from '../algorithms/indicators.js';

export class CandleCharacterStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.MIN_BODY_TO_WICK_RATIO = 0.6;
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) this.analyzeCandle();
        });
    }

    analyzeCandle() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < 1) return;
        
        const candle = candles[candles.length - 1];
        const { open, high, low, close } = candle;
        
        const bodySize = Math.abs(close - open);
        const totalSize = high - low;
        if (totalSize === 0) return;

        const bodyRatio = bodySize / totalSize;
        if (bodyRatio < this.MIN_BODY_TO_WICK_RATIO) return;

        if (close > open) {
            const upperWick = high - close;
            if (upperWick / totalSize < 0.2) { 
                this.propose('buy', 4, 'Güçlü Alıcı Mumu');
            }
        } else {
            const lowerWick = close - low;
            if (lowerWick / totalSize < 0.2) { 
                this.propose('sell', 4, 'Güçlü Satıcı Mumu');
            }
        }
    }
}
