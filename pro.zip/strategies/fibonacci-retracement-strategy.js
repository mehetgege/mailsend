// strategies/fibonacci-retracement-strategy.js

import { Strategy } from './base-strategy.js';

export class FibonacciRetracementStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.LOOKBACK = 120;
        this.TOLERANCE = 0.002;
        this.levels = [0.382, 0.5, 0.618];
        
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) {
                this.periodicAnalyze();
            }
        });
    }

    periodicAnalyze() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < this.LOOKBACK) return;
        
        const slice = candles.slice(-this.LOOKBACK);
        let high = -Infinity, low = Infinity, highTime = 0, lowTime = 0;
        
        slice.forEach(candle => { 
            if (candle.high > high) {
                high = candle.high;
                highTime = candle.time;
            }
            if (candle.low < low) {
                low = candle.low;
                lowTime = candle.time;
            }
        });
        
        if (!isFinite(high) || !isFinite(low) || high === low) return;
        
        const lastCandle = slice[slice.length - 1];
        
        if (highTime > lowTime) { // Yükseliş trendi
            const retracement = (high - lastCandle.close) / (high - low);
            for (const level of this.levels) {
                if (Math.abs(retracement - level) < this.TOLERANCE) { 
                    this.propose('buy', 3, `Fibo ${Math.round(level * 100)}% Bölgesi`);
                    return;
                }
            }
        } else { // Düşüş trendi
            const retracement = (lastCandle.close - low) / (high - low);
            for (const level of this.levels) {
                if (Math.abs(retracement - level) < this.TOLERANCE) { 
                    this.propose('sell', 3, `Fibo ${Math.round(level * 100)}% Bölgesi`);
                    return;
                }
            }
        }
    }
}
