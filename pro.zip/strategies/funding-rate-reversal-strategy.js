// strategies/funding-rate-reversal-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateBB } from '../algorithms/indicators.js';
import { calculateATR } from '../algorithms/indicators.js';
import { calculateVWAP } from '../algorithms/indicators.js';
import { calculateSuperTrend } from '../algorithms/indicators.js';
import { calculateRSI } from '../algorithms/indicators.js';

export class FundingRateReversalStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.fundingRate = 0;
        this.lastFetchTime = 0;
        this.FETCH_INTERVAL_MS = 60 * 1000;
        this.EXTREME_FUNDING_THRESHOLD = 0.001;
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) this.fetchFundingRate();
        });
    }

    async fetchFundingRate() {
        const now = Date.now();
        if (now - this.lastFetchTime < this.FETCH_INTERVAL_MS) return;

        this.lastFetchTime = now;
        const symbol = this.stateManager.getState('currentSymbol');
        try {
            const response = await fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${symbol}`);
            if (!response.ok) throw new Error(response.statusText);
            const data = await response.json();
            this.fundingRate = parseFloat(data.lastFundingRate);
            this.checkReversal();
        } catch (e) { 
            this.eventBus.publish('log', `Fonlama Oranı verisi çekilemedi: ${e.message}`);
        }
    }

    checkReversal() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        const currentPrice = this.stateManager.getNestedState('marketData.price');
        
        if (!candles || candles.length < 2 || !currentPrice) return;

        if (this.fundingRate > this.EXTREME_FUNDING_THRESHOLD) {
            if (currentPrice < candles[candles.length - 2].close) { 
                 this.propose('sell', 4, `Aşırı Pozitif Fonlama & Fiyat Düşüşü`);
            }
        } else if (this.fundingRate < -this.EXTREME_FUNDING_THRESHOLD) {
             if (currentPrice > candles[candles.length - 2].close) { 
                this.propose('buy', 4, `Aşırı Negatif Fonlama & Fiyat Yükselişi`);
            }
        }
    }
}
