// strategies/liquidity-gaps-strategy.js

import { Strategy } from './base-strategy.js';

export class LiquidityGapsStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.GAP_THRESHOLD_PERCENT = 0.001;
    }

    onOrderBook(orderBook) {
        if (!orderBook.a || !orderBook.b || orderBook.a.length === 0 || orderBook.b.length === 0) {
            return;
        }
        
        const asks = orderBook.a;
        const bids = orderBook.b;
        
        for (let i = 0; i < asks.length - 1; i++) { 
            const price1 = parseFloat(asks[i][0]);
            const price2 = parseFloat(asks[i + 1][0]);
            const gap = price2 - price1; 
            
            if ((gap / price1) > this.GAP_THRESHOLD_PERCENT) { 
                this.propose('buy', 3, `Likidite Boşluğu ${price1.toFixed(this.getDecimalPlaces(price1))}`);
                return; 
            } 
        }

        for (let i = 0; i < bids.length - 1; i++) { 
            const price1 = parseFloat(bids[i][0]);
            const price2 = parseFloat(bids[i + 1][0]);
            const gap = price1 - price2; 
            
            if ((gap / price1) > this.GAP_THRESHOLD_PERCENT) { 
                this.propose('sell', 3, `Likidite Boşluğu ${price1.toFixed(this.getDecimalPlaces(price1))}`);
                return; 
            } 
        }
    }
    
    getDecimalPlaces(price) {
        if (!price) return 2;
        if (price > 1000) return 2;
        if (price > 1) return 3;
        if (price > 0.01) return 4;
        return 6;
    }
}
