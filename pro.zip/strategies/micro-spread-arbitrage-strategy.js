// strategies/micro-spread-arbitrage-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateVWAP } from '../algorithms/indicators.js';
import { calculateATR } from '../algorithms/indicators.js';
import { calculateSuperTrend } from '../algorithms/indicators.js';
import { calculateRSI } from '../algorithms/indicators.js';
import { calculateBB } from '../algorithms/indicators.js';

export class MicroSpreadArbitrageStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.SPREAD_PCT = 0.0008;
    }

    onOrderBook(orderBook) {
        if (!orderBook.a || !orderBook.b || orderBook.a.length === 0 || orderBook.b.length === 0) return;
        
        const bestBid = parseFloat(orderBook.b[0][0]);
        const bestAsk = parseFloat(orderBook.a[0][0]);
        const mid = (bestAsk + bestBid) / 2;
        const spreadPct = (bestAsk - bestBid) / mid;
        
        if (spreadPct > this.SPREAD_PCT) {
            const currentPrice = this.stateManager.getNestedState('marketData.price') || mid;
            if (currentPrice < mid) {
                this.propose('buy', 2, 'Geniş Spread - Ortalamaya Dönüş');
            } else {
                this.propose('sell', 2, 'Geniş Spread - Ortalamaya Dönüş');
            }
        }
    }
}
