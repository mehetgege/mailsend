// strategies/order-flow-momentum-strategy.js

import { Strategy } from './base-strategy.js';

export class OrderFlowMomentumStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.trades = [];
        this.WINDOW_MS = 5000;
        this.IMBALANCE_THRESHOLD = 0.7;
    }

    onTrade(trade) {
        const now = Date.now(); 
        const tradeData = {
            timestamp: now,
            price: parseFloat(trade.p),
            quantity: parseFloat(trade.q),
            isBuyerMaker: trade.m
        };
        
        this.trades.push(tradeData); 
        this.trades = this.trades.filter(t => now - t.timestamp < this.WINDOW_MS); 
        
        if (this.trades.length < 50) return;
        
        const buys = this.trades.filter(t => !t.isBuyerMaker).reduce((sum, t) => sum + t.quantity, 0); 
        const sells = this.trades.filter(t => t.isBuyerMaker).reduce((sum, t) => sum + t.quantity, 0);
        
        const total = buys + sells; 
        if (total === 0) return; 

        if (buys / total > this.IMBALANCE_THRESHOLD) { 
            this.propose('buy', 4, `Alıcı Akışı: %${(buys / total * 100).toFixed(0)}`); 
            this.trades = []; 
        } else if (sells / total > this.IMBALANCE_THRESHOLD) { 
            this.propose('sell', 4, `Satıcı Akışı: %${(sells / total * 100).toFixed(0)}`); 
            this.trades = []; 
        }
    }
}
