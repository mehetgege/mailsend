// strategies/rsi-divergence-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateRSI } from '../algorithms/indicators.js';

export class RsiDivergenceStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.RSI_PERIOD = 14;
        this.LOOKBACK_CANDLES = 40;
        this.SWING_PERIOD = 5;
        
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) {
                this.periodicAnalyze();
            }
        });
    }

    periodicAnalyze() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < this.LOOKBACK_CANDLES) return;
        
        const closes = candles.map(c => c.close);
        const rsiValues = calculateRSI(closes, this.RSI_PERIOD);
        
        if (!rsiValues || rsiValues.length < this.LOOKBACK_CANDLES) return;
        
        const priceSlice = candles.slice(-this.LOOKBACK_CANDLES);
        const rsiSlice = rsiValues.slice(-this.LOOKBACK_CANDLES);

        const pivLows = [], pivHighs = [];
        for (let i = this.SWING_PERIOD; i < priceSlice.length - this.SWING_PERIOD; i++) {
            const isPivotLow = priceSlice[i].low < Math.min(...priceSlice.slice(i - this.SWING_PERIOD, i).map(x => x.low)) && 
                               priceSlice[i].low < Math.min(...priceSlice.slice(i + 1, i + 1 + this.SWING_PERIOD).map(x => x.low));
            const isPivotHigh = priceSlice[i].high > Math.max(...priceSlice.slice(i - this.SWING_PERIOD, i).map(x => x.high)) && 
                                priceSlice[i].high > Math.max(...priceSlice.slice(i + 1, i + 1 + this.SWING_PERIOD).map(x => x.high));
            if (isPivotLow) pivLows.push(i);
            if (isPivotHigh) pivHighs.push(i);
        }

        // Normal Boğa Sapması (Bullish Divergence)
        if (pivLows.length >= 2) {
            const i1 = pivLows[pivLows.length - 2];
            const i2 = pivLows[pivLows.length - 1];
            if (priceSlice[i2].low < priceSlice[i1].low && rsiSlice[i2] > rsiSlice[i1]) {
                this.propose('buy', 5, 'Normal Boğa Sapması (RSI)');
            }
        }
        
        // Normal Ayı Sapması (Bearish Divergence)
        if (pivHighs.length >= 2) {
            const i1 = pivHighs[pivHighs.length - 2];
            const i2 = pivHighs[pivHighs.length - 1];
            if (priceSlice[i2].high > priceSlice[i1].high && rsiSlice[i2] < rsiSlice[i1]) {
                this.propose('sell', 5, 'Normal Ayı Sapması (RSI)');
            }
        }
        
        // Gizli Boğa Sapması (Hidden Bullish Divergence)
        if (pivLows.length >= 2) {
            const i1 = pivLows[pivLows.length - 2];
            const i2 = pivLows[pivLows.length - 1];
            if (priceSlice[i2].low > priceSlice[i1].low && rsiSlice[i2] < rsiSlice[i1]) {
                this.propose('buy', 4, 'Gizli Boğa Sapması (RSI)');
            }
        }
        
        // Gizli Ayı Sapması (Hidden Bearish Divergence)
        if (pivHighs.length >= 2) {
            const i1 = pivHighs[pivHighs.length - 2];
            const i2 = pivHighs[pivHighs.length - 1];
            if (priceSlice[i2].high < priceSlice[i1].high && rsiSlice[i2] > rsiSlice[i1]) {
                this.propose('sell', 4, 'Gizli Ayı Sapması (RSI)');
            }
        }
    }
}
