// strategies/smart-money-concepts-strategy.js

import { Strategy } from './base-strategy.js';

export class SmartMoneyConceptsStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.GAP_MIN_PERCENT = 0.0005;
        
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) {
                this.periodicAnalyze();
            }
        });
    }

    periodicAnalyze() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < 3) return;
        
        const lastCandle = candles[candles.length - 1];
        const previousCandle = candles[candles.length - 2];
        const twoCandlesAgo = candles[candles.length - 3];

        // Boğa FVG tespiti
        if (lastCandle.low > previousCandle.high && (lastCandle.low - previousCandle.high) / lastCandle.low > this.GAP_MIN_PERCENT) {
             this.propose('buy', 4, 'Boğa FVG (Fiyat Verimsizlik Boşluğu)');
        }
        
        // Ayı FVG tespiti
        if (twoCandlesAgo.high > previousCandle.low && (twoCandlesAgo.high - previousCandle.low) / previousCandle.low > this.GAP_MIN_PERCENT) {
            this.propose('sell', 4, 'Ayı FVG (Fiyat Verimsizlik Boşluğu)');
        }
    }
}
