// strategies/super-trend-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateSuperTrend } from '../algorithms/indicators.js';
import { calculateATR } from '../algorithms/indicators.js';
import { calculateVWAP } from '../algorithms/indicators.js';
import { calculateRSI } from '../algorithms/indicators.js';
import { calculateBB } from '../algorithms/indicators.js';

export class SuperTrendStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.MULT = 3.0;
        this.PERIOD = 14;
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) this.analyzeSuperTrend();
        });
    }

    analyzeSuperTrend() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < this.PERIOD) return;
        
        const superTrend = calculateSuperTrend(candles, this.PERIOD, this.MULT);
        if (!superTrend) return;
        
        const lastCandle = candles[candles.length - 1];
        const lastSuperTrend = superTrend[superTrend.length - 1];
        
        if (lastCandle.close > lastSuperTrend) {
            this.propose('buy', 4, 'ATR Kanal Üstü Kırılım (SuperTrend)');
        } else if (lastCandle.close < lastSuperTrend) {
            this.propose('sell', 4, 'ATR Kanal Altı Kırılım (SuperTrend)');
        }
    }
}
