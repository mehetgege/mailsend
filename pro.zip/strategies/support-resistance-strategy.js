// strategies/support-resistance-strategy.js

import { Strategy } from './base-strategy.js';

export class SupportResistanceStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.LOOKBACK = 60;
        this.THRESH = 0.0015;
        
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) {
                this.periodicAnalyze();
            }
        });
    }

    periodicAnalyze() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < this.LOOKBACK) return;
        
        const slice = candles.slice(-this.LOOKBACK);
        const lastCandle = slice[slice.length - 1];
        
        const maxHigh = Math.max(...slice.map(c => c.high));
        const minLow = Math.min(...slice.map(c => c.low));
        
        const distanceToResistance = (maxHigh - lastCandle.close) / lastCandle.close;
        const distanceToSupport = (lastCandle.close - minLow) / lastCandle.close;
        
        if (distanceToResistance >= 0 && distanceToResistance < this.THRESH && lastCandle.close < lastCandle.open) {
            this.propose('sell', 3, 'Direnç Bölgesi Reddi');
        }
        
        if (distanceToSupport >= 0 && distanceToSupport < this.THRESH && lastCandle.close > lastCandle.open) {
            this.propose('buy', 3, 'Destek Bölgesi Tepkisi');
        }
    }
}
