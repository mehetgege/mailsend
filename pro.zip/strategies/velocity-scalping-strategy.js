// strategies/velocity-scalping-strategy.js

import { Strategy } from './base-strategy.js';

export class VelocityScalpingStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.pricePoints = [];
        this.VELOCITY_WINDOW_MS = 2000;
        this.MIN_POINTS = 20;
        this.VELOCITY_THRESHOLD_PERCENT = 0.001;
    }

    onTrade(trade) {
        const now = Date.now(); 
        const tradePrice = parseFloat(trade.p);
        this.pricePoints.push({ time: now, price: tradePrice }); 
        this.pricePoints = this.pricePoints.filter(p => now - p.time < this.VELOCITY_WINDOW_MS); 
        
        if (this.pricePoints.length < this.MIN_POINTS) {
            return;
        }
        
        const firstPoint = this.pricePoints[0]; 
        const lastPoint = this.pricePoints[this.pricePoints.length - 1]; 
        const priceChange = (lastPoint.price - firstPoint.price) / firstPoint.price;
        
        if (priceChange > this.VELOCITY_THRESHOLD_PERCENT) { 
            this.propose('buy', 4, `Fiyat Hızı: +${(priceChange * 100).toFixed(2)}%`);
            this.pricePoints = [];
        } else if (priceChange < -this.VELOCITY_THRESHOLD_PERCENT) { 
            this.propose('sell', 4, `Fiyat Hızı: ${(priceChange * 100).toFixed(2)}%`);
            this.pricePoints = [];
        }
    }
}
