// strategies/volatility-breakout-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateBB } from '../algorithms/indicators.js';
import { calculateATR } from '../algorithms/indicators.js';
import { calculateVWAP } from '../algorithms/indicators.js';
import { calculateSuperTrend } from '../algorithms/indicators.js';
import { calculateRSI } from '../algorithms/indicators.js';

export class VolatilityBreakoutStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.SQUEEZE_LOOKBACK = 20;
        this.SQUEEZE_MULT = 1.0;
        this.BREAKOUT_VOL_MULT = 1.5;
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) this.analyzeBreakout();
        });
    }

    analyzeBreakout() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < this.SQUEEZE_LOOKBACK) return;
        
        const bbands = calculateBB(candles, this.SQUEEZE_LOOKBACK, 2);
        const atr = calculateATR(candles, 14);
        
        if (!bbands || !atr) return;
        
        const lastBandwidth = (bbands.upper - bbands.lower) / bbands.middle;
        const isSqueeze = lastBandwidth < (atr / candles[candles.length - 1].close) * this.SQUEEZE_MULT;
        
        if(!isSqueeze) return;
        
        const lastCandle = candles[candles.length - 1];
        const prevVolumes = candles.slice(-this.SQUEEZE_LOOKBACK, -1).map(c => c.volume);
        const avgVol = prevVolumes.reduce((a,b) => a+b, 0) / prevVolumes.length;

        if (lastCandle.close > bbands.upper && lastCandle.volume > avgVol * this.BREAKOUT_VOL_MULT) {
            this.propose('buy', 5, 'Volatilite Sıkışma Kırılımı (Yukarı)');
        } else if (lastCandle.close < bbands.lower && lastCandle.volume > avgVol * this.BREAKOUT_VOL_MULT) {
            this.propose('sell', 5, 'Volatilite Sıkışma Kırılımı (Aşağı)');
        }
    }
}
