// strategies/volume-profile-strategy.js

import { Strategy } from './base-strategy.js';

export class VolumeProfileStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.PERIOD = 20;
        this.SPIKE = 2.0;
        this.CLOSE_POS = 0.7;
        
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) {
                this.periodicAnalyze();
            }
        });
    }

    periodicAnalyze() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        if (!candles || candles.length < this.PERIOD + 1) return;
        
        const lastCandle = candles[candles.length - 1];
        const prevCandles = candles.slice(-this.PERIOD - 1, -1);
        const volumes = prevCandles.map(c => c.volume);
        
        const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;
        
        if (lastCandle.volume > avgVolume * this.SPIKE) {
            const candleRange = lastCandle.high - lastCandle.low;
            if (candleRange === 0) return;
            
            const closePosition = (lastCandle.close - lastCandle.low) / candleRange;
            
            if (closePosition > this.CLOSE_POS) {
                this.propose('buy', 3, 'Hacim Spike - Üst Kapanış');
            } else if (closePosition < (1 - this.CLOSE_POS)) {
                this.propose('sell', 3, 'Hacim Spike - Alt Kapanış');
            }
        }
    }
}
