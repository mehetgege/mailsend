// strategies/vwap-reversion-strategy.js

import { Strategy } from './base-strategy.js';
import { calculateVWAP } from '../algorithms/indicators.js';
import { calculateATR } from '../algorithms/indicators.js';
import { calculateSuperTrend } from '../algorithms/indicators.js';
import { calculateRSI } from '../algorithms/indicators.js';
import { calculateBB } from '../algorithms/indicators.js';

export class VWAPReversionStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        this.MULT = 1.0;
        this.ATR_PERIOD = 14;
        this.eventBus.subscribe('websocket:message', (data) => {
            if (data.stream.includes('@kline') && data.data.k.x) this.analyzeVWAP();
        });
    }

    analyzeVWAP() {
        const candles = this.stateManager.getNestedState('marketData.candles');
        const price = this.stateManager.getNestedState('marketData.price');
        
        if (!candles || candles.length < this.ATR_PERIOD || !price) return;
        
        const vwap = calculateVWAP(candles);
        const atr = calculateATR(candles, this.ATR_PERIOD);
        
        if (!vwap || !atr) return;
        
        const diffPrice = price - vwap;
        
        if (diffPrice > this.MULT * atr) {
            this.propose('sell', 3, 'VWAP Üstü Aşırı Sapma');
        } else if (diffPrice < -this.MULT * atr) {
            this.propose('buy', 3, 'VWAP Altı Aşırı Sapma');
        }
    }
}
