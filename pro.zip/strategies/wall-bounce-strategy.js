// strategies/wall-bounce-strategy.js

import { Strategy } from './base-strategy.js';

export class WallBounceStrategy extends Strategy {
    constructor(eventBus, stateManager, name) {
        super(eventBus, stateManager, name);
        // Piyasa fiyatına yakın büyük emir duvarlarını arar.
        this.DISTANCE_THRESHOLD_PERCENT = 0.0005;
        this.WALL_BTC_THRESHOLD = 20;
    }

    onOrderBook(orderBook) {
        const currentPrice = this.stateManager.getNestedState('marketData.price');
        if (!currentPrice || !orderBook) return;
        
        // Emir duvarı eşiğini dinamik olarak hesapla (BTC cinsinden)
        const btcPrice = this.stateManager.getNestedState('marketData.btcPrice') || 70000;
        const wallQuantityThreshold = (this.WALL_BTC_THRESHOLD * btcPrice) / currentPrice;

        // Satış emirlerini (asks) kontrol et
        if (orderBook.a) {
            for (const [price, qty] of orderBook.a) { 
                const priceFloat = parseFloat(price);
                const qtyFloat = parseFloat(qty);
                // Eğer emir miktarı eşiği aşarsa
                if (qtyFloat > wallQuantityThreshold) { 
                    const distance = (priceFloat - currentPrice) / currentPrice; 
                    // Fiyat emir duvarına yeterince yakınsa satış sinyali gönder
                    if (distance > 0 && distance < this.DISTANCE_THRESHOLD_PERCENT) { 
                        this.propose('sell', 3, `Satış Duvarı ${priceFloat.toFixed(this.getDecimalPlaces(priceFloat))}`);
                        return; // Tek bir sinyal yeterli
                    } 
                } 
            }
        }

        // Alış emirlerini (bids) kontrol et
        if (orderBook.b) {
            for (const [price, qty] of orderBook.b) { 
                const priceFloat = parseFloat(price);
                const qtyFloat = parseFloat(qty);
                // Eğer emir miktarı eşiği aşarsa
                if (qtyFloat > wallQuantityThreshold) { 
                    const distance = (currentPrice - priceFloat) / currentPrice; 
                    // Fiyat emir duvarına yeterince yakınsa alış sinyali gönder
                    if (distance > 0 && distance < this.DISTANCE_THRESHOLD_PERCENT) { 
                        this.propose('buy', 3, `Alış Duvarı ${priceFloat.toFixed(this.getDecimalPlaces(priceFloat))}`);
                        return; // Tek bir sinyal yeterli
                    } 
                } 
            }
        }
    }
    
    getDecimalPlaces(price) {
        if (!price) return 2;
        if (price > 1000) return 2;
        if (price > 1) return 3;
        if (price > 0.01) return 4;
        return 6;
    }
}
