// visualizers/chart-manager.js

class ChartManager {
    constructor(chartContainerId, stateManager) {
        this.chartContainer = document.getElementById(chartContainerId);
        this.stateManager = stateManager;
        if (!this.chartContainer) {
            throw new Error(`Chart container '${chartContainerId}' bulunamadı!`);
        }
        this.chart = null;
        this.series = {};
        this.signalMarkers = [];
        this.initChart();
        this.stateManager.eventBus.subscribe('ui:theme_changed', () => this.updateTheme());
    }

    initChart() {
        this.chart = LightweightCharts.createChart(this.chartContainer, this.getChartOptions());
        this.series.candles = this.chart.addCandlestickSeries(this.getCandlestickOptions());
        this.series.volume = this.chart.addHistogramSeries(this.getVolumeOptions());
        
        window.addEventListener('resize', () => this.resizeChart());
    }

    resizeChart() {
        if (this.chart && this.chartContainer.clientWidth > 0 && this.chartContainer.clientHeight > 0) {
            this.chart.resize(this.chartContainer.clientWidth, this.chartContainer.clientHeight);
        }
    }

    updateTheme() {
        if (!this.chart) return;
        this.chart.applyOptions(this.getChartOptions());
        this.series.candles.applyOptions(this.getCandlestickOptions());
        this.series.volume.applyOptions(this.getVolumeOptions());
    }

    setData(candles) {
        if (!this.series.candles || !candles) return;
        const candleData = candles.map(c => ({
            time: c.time / 1000,
            open: c.open,
            high: c.high,
            low: c.low,
            close: c.close
        }));
        const volumeData = candles.map(c => ({
            time: c.time / 1000,
            value: c.volume,
            color: c.close >= c.open ? 'rgba(40, 167, 69, 0.5)' : 'rgba(220, 53, 69, 0.5)'
        }));
        this.series.candles.setData(candleData);
        this.series.volume.setData(volumeData);
        this.chart.timeScale().fitContent();
    }
    
    updateRealtime(kline) {
        if (!this.series.candles) return;
        const candle = {
            time: kline.t / 1000,
            open: parseFloat(kline.o),
            high: parseFloat(kline.h),
            low: parseFloat(kline.l),
            close: parseFloat(kline.c)
        };
        const volume = {
            time: kline.t / 1000,
            value: parseFloat(kline.v),
            color: candle.close >= candle.open ? 'rgba(40, 167, 69, 0.5)' : 'rgba(220, 53, 69, 0.5)'
        };
        this.series.candles.update(candle);
        this.series.volume.update(volume);
    }

    addMarker(signal) {
        if (!this.series.candles) return;
        const styles = getComputedStyle(document.body);
        const marker = {
            time: signal.timestamp / 1000,
            position: signal.direction === 'buy' ? 'belowBar' : 'aboveBar',
            color: signal.direction === 'buy' ? styles.getPropertyValue('--positive').trim() : styles.getPropertyValue('--negative').trim(),
            shape: signal.direction === 'buy' ? 'arrowUp' : 'arrowDown',
            text: signal.direction.toUpperCase()
        };
        this.signalMarkers.push(marker);
        this.series.candles.setMarkers(this.signalMarkers);
    }
    
    clearMarkers() {
        if (!this.series.candles) return;
        this.signalMarkers = [];
        this.series.candles.setMarkers([]);
    }

    getChartOptions() {
        const styles = getComputedStyle(document.body);
        return {
            width: this.chartContainer.clientWidth,
            height: this.chartContainer.clientHeight,
            layout: {
                backgroundColor: 'transparent',
                textColor: styles.getPropertyValue('--text-main').trim(),
                fontFamily: "'Roboto Mono', monospace"
            },
            grid: {
                vertLines: { color: styles.getPropertyValue('--border-color').trim() },
                horzLines: { color: styles.getPropertyValue('--border-color').trim() }
            },
            crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
            timeScale: { borderColor: styles.getPropertyValue('--border-color').trim(), timeVisible: true, secondsVisible: false, rightOffset: 10 }
        };
    }

    getCandlestickOptions() {
        const styles = getComputedStyle(document.body);
        return { 
            upColor: styles.getPropertyValue('--positive').trim(),
            downColor: styles.getPropertyValue('--negative').trim(),
            borderVisible: false,
            wickUpColor: styles.getPropertyValue('--positive').trim(),
            wickDownColor: styles.getPropertyValue('--negative').trim()
        };
    }

    getVolumeOptions() {
        return { 
            priceFormat: { type: 'volume' },
            priceScaleId: '',
            scaleMargins: { top: 0.8, bottom: 0 }
        };
    }
}
export { ChartManager };
