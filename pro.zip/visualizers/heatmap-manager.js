// visualizers/heatmap-manager.js

class HeatmapManager {
    constructor(canvasId, stateManager) {
        this.canvas = document.getElementById(canvasId);
        this.stateManager = stateManager;
        if (!this.canvas) {
            throw new Error(`Heatmap canvas '${canvasId}' bulunamadı!`);
        }
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        this.stateManager.eventBus.subscribe('ui:theme_changed', () => this.updateTheme());
    }

    draw(orderBook) {
        if (!orderBook.a || !orderBook.b || orderBook.a.length === 0 || orderBook.b.length === 0) {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            return;
        }

        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        const asks = orderBook.a.slice().reverse();
        const bids = orderBook.b;
        const allLevels = [...bids, ...asks];
        const maxQty = Math.max(...allLevels.map(l => parseFloat(l[1])));
        const currentPrice = this.stateManager.getNestedState('marketData.price');

        this.drawSection(asks, 'asks', maxQty, currentPrice);
        this.drawSection(bids, 'bids', maxQty, currentPrice);
    }
    
    updateTheme() {
        this.resizeCanvas();
    }

    drawSection(levels, type, maxQty, symbolPrice) {
        const styles = getComputedStyle(document.body);
        const baseColor = type === 'asks' ? styles.getPropertyValue('--negative').trim() : styles.getPropertyValue('--positive').trim();
        if (levels.length === 0) return;
        
        const heightPerLevel = (this.canvas.height / 2) / levels.length;
        const priceDecimals = this.getDecimalPlaces(symbolPrice);
        const labelSkipInterval = heightPerLevel < 12 ? Math.ceil(12 / heightPerLevel) : 1;
        
        levels.forEach((level, index) => {
            const [price, qty] = [parseFloat(level[0]), parseFloat(level[1])];
            const intensity = Math.min(Math.sqrt(qty / maxQty), 1.0);
            this.ctx.fillStyle = this.hexToRgba(baseColor, intensity * 0.6 + 0.1);
            const y = type === 'asks' ? index * heightPerLevel : (this.canvas.height / 2) + (index * heightPerLevel);
            const barWidth = this.canvas.width * intensity;
            
            this.ctx.fillRect(0, y, barWidth, heightPerLevel);
            
            if (index % labelSkipInterval === 0) {
                this.ctx.fillStyle = intensity > 0.5 ? '#FFFFFF' : styles.getPropertyValue('--text-secondary').trim();
                this.ctx.font = '10px "Roboto Mono"';
                this.ctx.textAlign = 'left';
                this.ctx.fillText(`${qty.toFixed(2)} @ ${price.toFixed(priceDecimals)}`, 10, y + heightPerLevel - 3);
            }
        });
    }

    resizeCanvas() { 
        if (this.canvas.parentElement) {
            this.canvas.width = this.canvas.parentElement.clientWidth; 
            this.canvas.height = this.canvas.parentElement.clientHeight; 
        }
    }
    
    getDecimalPlaces(price) {
        if (!price) return 2;
        if (price > 1000) return 2;
        if (price > 1) return 3;
        if (price > 0.01) return 4;
        return 6;
    }

    hexToRgba(hex, alpha) {
        if (!hex.startsWith('#')) return `rgba(120,120,120,${alpha})`;
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
}
export { HeatmapManager };
